# Azure CloudOps

Cloud Azure (CloudOps) implementation for Zabbix.