# Galera arbitrator role

This role install a galera arbitrator.

## Variables to define

* mariadb_galera_cluster_name {cluster name of the mariadb galera cluster}

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

To avoid ip:port conflict, this role should not be initialize on a target running a galera cluster instance.
Otherwise the systemctl journal will report the conflict : [ERROR] bind address already in use.
During the test process, it was running smoothly on the same server as Zabbix master server which was not part of the cluster.

## Behavior

The role needs to access mariadb host group to generate the configuration file correctly.
By default, it looks for the group "mariadbCluster" in the inventory. It then take all the ip of this group to match the cluster configuration.
If the hostgroup as another name, it needs to be changed on the file [...]/template/etc/sysconfig/garb.j2