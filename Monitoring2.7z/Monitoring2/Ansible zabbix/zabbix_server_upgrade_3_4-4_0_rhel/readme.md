# Role zabbix_server_upgrade_3_4-4_0_rhel

This role goal is to upgrade a zabbix server from a 3.4 version to a 4.0 version.
This role use a zabbix database saver from the following repository https://github.com/maxhq/zabbix-backup/releases/latest
This additional repository is under MIT license.

## Behavior

First, the role check the version of zabbix and stop zabbix services.
Then, if the zabbix version is a 4.X version, the script try to install the latest version of zabbix 4.
If not, the playbook run the full configuration. In that case, it create a back up of the zabbix configuration and a back up of the mariadb database. Each time the function is called, it create a back of the configuration of the server it is installed on. In case the zabbix is installed as a standalone with its own database, both saves will be on the same server.
In case the database is distant or is a cluster, every instance of zabbix called will have a save localy. In case the upgraded zabbix is part of the cluster and the all cluster is being upgraded, every zabbix server will have a local save. => this part should be modified to transfert the save to the ansible machin and secured it by the way.
When everything is saved, it then install the zabbix 4.0 repository to the zabbix server and upgrade all the zabbix related services.
To finish the process, the ansible role restart zabbix server and zabbix agent.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables to define

* database_type {define the type of the database: mysql in our default case}
* db_host {define the database host which need saving. need to be an IP address}
* db_port {define the database port to connect}
* db_name {define the zabbix database name}
* db_user {define the zabbix database }
* db_password {define the zabbix database password}

### Security

During the process of installation, different elements will need root priviledges to be installed correctly.
To secure the password or sensibles variables we can use an encrypted var_file.
For more information look ansible vault: https://docs.ansible.com/ansible/latest/user_guide/vault.html

### Inventory

This role does not need a specific configuration of the inventory.

```
[zabbixGroup]
hostname_of_the_host ansible_host=ip_of_the_host privatekeyfile=/path/to/key ansible_user=user_to_connect ansible_become_pass='{{ SuperPass }}'

[zabbixGroup:vars]
ansible_become=yes
ansible_become_method=su
```