# Keepalived role

This role install a keepalived/virtual ip on a galera/mariaDB cluster.

## Variables to define

* mariadb_master_ip { IP of the mariadb master of the cluster }
* mysql_username_keep { User for the check script to access mysql }
* mysql_password_keep { Password for the check script to access mysql }
* lvl { level of the target to configure (master or slave) }
* virtual_ip_mariadb { virtual ip to configure the keepalived }

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Behavior

The role auto generate configuration files from ansible variables/facts and inventory variables to create keepalived configuration and prepare the virtual ip.
This role add a user to monitor the state of the cluster and the different servers of the cluster.
It add a script to mariadb cluster's hosts which verify the change of master in case of connection failure.

### Security

In order to check if the mariadb cluster server is still alive, the script need a user to use mysql.
It is needed to define a "mysql_username_keep" and a "mysql_password_keep".
Also it need to access the mysql so the var "mariadb_master_ip" has to be defined.

### Inventory and Targets

In the inventory, it's needed to define which host is a master and which one is a slave (backup).
You need to define, "lvl" with the value : "master" or "slave"

```

[mariadbCluster]
hostname_of_the_host ansible_host=ip_of_the_host privatekeyfile=/path/to/key ansible_user=user_to_connect ansible_become_pass='{{ SuperPass }}'lvl=master

[mariadbCluster:vars]
ansible_become=yes
ansible_become_method=su

```

Priority of the master is also defined by the "lvl" variable.

This role need a virtual ip to set up the keepalived service.
You need to define "virtual_ip_mariaDB".
