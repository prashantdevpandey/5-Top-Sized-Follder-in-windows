# Role zabbix-agent

This is a role to deploy zabbix agent on a RHEL 7 server.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables to define

* virtual_ip_zabbix {ip of the zabbix cluster}

## Behavior

First the role verify that zabbix agent is not already installed. Note that the agent can fail, it will still be considered as installed.
Then this role install zabbix 4.0 agent from the rhel/centos repos.
Then the role transfer the configuration needed to connect the agent to a zabbix ip in our case "virtual_ip_zabbix". The configuration file also contains the 127.0.0.1 ip to allow the reading of zabbix server by the agent.
The role also execute firewalld command to open zabbix agent port.

In this version of the role, the template etc/zabbix/zabbix_agentd.conf as 2 ip defined for "Server" parameter.
The first one is the virtual_ip_zabbix.
The second one is the classic localhost ip aka 127.0.0.1 which allow the installation of the agent on the zabbix_server. Otherwise, the agent failed and the zabbix server can not connect to his own agent throwing errors on the dashboard.