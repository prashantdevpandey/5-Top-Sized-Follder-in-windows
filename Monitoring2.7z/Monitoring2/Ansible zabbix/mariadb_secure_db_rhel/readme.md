#role mariadb_secure_db_rhel

This role change the password of the root user of a mysql/mariadb for localhost.
Basically, it is the same as a secure installation of mysql.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables

* mysql_root_password {new password for the root user}

## Behavior

This role change the root password for the password defined on the variables.
It also removes anonynous users. It deletes the database test.
And it also removes all remote connections.

## Informations

In case you want to totaly remove mariadb/mysql.

yum remove mariadb mysql keepalived galera
rm -R /etc/my.cnd.d /etc/mysql /etc/keepalived /var/lib/mysql