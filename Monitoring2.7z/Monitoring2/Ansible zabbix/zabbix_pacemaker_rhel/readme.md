# role zabbix_pacemaker_rhel

This role configure a pacemaker service.

Extension possible, take any server in a group to add them in the cluste.
The role in this version only take 2 define servers to add them in the cluster.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables

* isZabbixCluster {define if the host is part of the zabbix cluster}
* state {define if the server is a master or a standby of the zabbix cluster}
* hapassword {password for the ha user create on all zabbix servers}
* zabbix_server_hostname {hostname of the zabbix master}
* zabbix_standby_hostname {hostname of the zabbix standby}
* virtual_ip_zabbix {virtual ip on which the cluster is installed}
* cluster_mask_defined {mask of the cluster related with the virtual ip}

## Behavior

This role install and configure pacemaker on a zabbix master instance to create a cluster with a zabbix standby on another server. The configuration is installed on any server which have 2 specific variables defined on the inventory. Those variables are isZabbixCluster and state.
The role need a specific order to install correctly the cluster.
The primary server should only be configured after all the other servers received the pacemaker package, in our case, the other standby. 
We can define the hosts in the principal playbook as follow: 
> hosts: GroupOfStandBy:GroupOfPrimaryZabbix
With this, the playbook will first install on all the zabbix instance present on the GroupOfStandBy and then it will configure pacemaker as a cluster on  GroupOfPrimaryZabbix
This role first get all ip address and hostname of the inventory and add them to the /etc/hosts of the zabbix targets.


To verify the configuration, you can use the following commands:
> pcs status cluster
> pcs status nodes
> pcs cluster standby zabbix_server_hostname #test the end of the master and use of the standby
> pcs status

To destroy an existing configuration:

> pcs cluster stop
> pcs cluster destroy

It is possible to use --force for the last node of the pacemaker cluster.

### Security

This role use the ansible module user to add a user for the pacemaker management and the configuration.
This role also need a password for the user newly created. This password can be defined on a ansible-vault file. It wont be shown on the log nor produce trace during the ansible process so the only way to know what is the password is to know the password to unlock the ansible-vault file.

### Inventory

The variables can be defined in the inventory as in the example:

```
[zabbix-server]
hotsnameZabbixMaster ansible_host=ip.of.the.host privatekeyfile=/[...]/path/to/key ansible_user=ansibleUserToConnect state=primary isZabbixCluster=True ansible_become_pass='{{ zabbix_master_root_password }}'
hotsnameZabbixStandBy ansible_host=ip.of.the.host privatekeyfile=/[...]/path/to/key ansible_user=ansibleUserToConnect state=standby isZabbixCluster=True ansible_become_pass='{{ zabbix_standby_root_password }}' 

[zabbix-server:vars]
ansible_become=yes
ansible_become_method=su
```