#Role zabbix_agent_debian

This role install a Zabbix-agent on a specified debian 7/8/9.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables to define

* virtual_ip_zabbix { virtual ip of the zabbix cluster / ip of the zabbix master }

## Behavior

First the role verify that zabbix agent is not already installed. Note that the agent can fail, it will still be considered as installed.
Then this role look form the OS distribution and version and install with apt the zabbix agent corresponding.
Then the role transfer the configuration needed to connect the agent to a zabbix ip in our case "virtual_ip_zabbix".

### Inventory

Example of inventory:

```

[ZabbixTargetHost]
ZabbixPrimary ansible_host=Ip.ofThe.agent.target privatekeyfile=[...]/path/to/your/key ansible_user=UserToConnectOnTheTaget ansible_become_pass='{{ TargetRootPassword }}'

[ZabbixTargetHost:vars]
ansible_become=yes
ansible_become_method=su

```