# mariaDB role

This role install mariaDB cluster on a group of defined hosts in an inventory.
This role generate automaticaly the galera.conf file from the hosts in the defined group.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables to define

* lvl {define the state of the target, if it is a master or a slave}

## Behavior

This role install a mariadb cluster on a group of defined host. The master receive the configuration of the cluster and start the cluster. The slaves receive the elements needed to incorporate the cluster. The galera cluster package is transfered from the local files.

Galera version is 3.5.
Mariadb version is 10.3.
Versions are defined during the installation process in the file [...]/tasks/InstallPackages.yml

### Inventory

The hosts are configured regarding a specific parameter on the inventory.
The parameter "lvl" accept 2 values : "master" and "slave".
It has to be defined on the inventory as an extra variable.
!!! warning !!! 
The first host defined on the group should be the cluster master. Otherwise, the cluster will try to add element to the cluster when the cluster is not started or created yet.
!!! warning !!!

```

[mariadbCluster]
hostname_of_the_host ansible_host=ip_of_the_host privatekeyfile=/path/to/key ansible_user=user_to_connect ansible_become_pass='{{ SuperPass }}' lvl=master
hostname_of_the_host2 ansible_host=ip_of_the_host2 privatekeyfile=/path/to/key2 ansible_user=user_to_connect2 ansible_become_pass='{{ SuperPass2 }}' lvl=slave

[mariadbCluster:vars]
ansible_become=yes
ansible_become_method=su

```