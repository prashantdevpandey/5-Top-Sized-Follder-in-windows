# Role zabbix_distantdb_rhel

This role install a zabbix on a rhel server and connect it to a distant mariadb database.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables to define

* time_zone_zabbix {the time zone to define zabbix}
* virtual_ip_mariadb {ip of the mariadb cluster}
* zabbix_db_name {name of the zabbix db to connect}
* db_user {zabbix database username}
* db_password {zabbix database password} 

## Behavior

This role install a zabbix service on a rhel server.
The role is made to add instance alone or create a single unit to incorporate in a zabbix cluster.
First it install all the packages related to zabbix + snmp protocol + perl.
Then it transfert the configuration files.
The time zone is defined by the variable time_zone_zabbix in the file [...]/template/etc/httpd/conf.d/zabbix.j2
The other configuration file are also defined with variables and generated from those variables. [...]/template/etc/zabbix/*

### Inventory

The inventory does not required any specific variable.

```
[zabbix-server]
server_hostname ansible_host=server_ip privatekeyfile=/[...]/path/to/key ansible_user=user_to_connect ansible_become_pass='{{ server_root_password }}'

[zabbix-server:vars]
ansible_become=yes
ansible_become_method=su
```