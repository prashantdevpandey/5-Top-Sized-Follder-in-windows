# Ansible Init Zabbix cluster with Mariadb cluster

This repository main goal is to install a zabbix solution as a master/standby infrastructure with a mariadb cluster.

To launch the repository and the roles, use the command line on the repository and tap the following:

```
> ansible-playbook -i inventory/inventory --ask-vault-pass generalPlaybook.yml
> ansible-playbook -i inventory/inventory --ask-vault-pass zabbixImport.yml
```

The inventory (file with the network definition) used is inventory/inventory.  
The command ask for the encrypted password to use the var_files. --ask-vault-pass  
The command use the playbook: generalPlaybook.yml and zabbixImport.xml

## Requirements

The playbook and roles were developped with ansible 2.7 and thus need to be run with ansible 2.7 at least to ensure the well being of the process.
The playbook and the roles need a connection to internet in order to download various packages on the servers.

## Behavior expected

The repository playbook, generalPlaybook.yml, use different steps to install the zabbix solution.  
- First, it installs the mariadb cluster and add a zabbix agent to every member of the mariadb cluster.  
- Then, it prepare the mariadb cluster to receive zabbix informations. It creates the zabbix user, alter the database and import various elements for zabbix.  
- When the database is correctly set and ready to use, the playbook then install zabbix and its agent on the different servers defined in the inventory.  
- After that, the playbook add the pacemaker configuration to all the zabbix instance across the hostgroups and start the pacemaker "cluster".  

Once the configuration by default of zabbix cluster and mariadb cluster is done, we need to create a zabbix api user with super admin rights.
When it is done, we can use the correponding role to import zabbix xml template.

- At the end, the zabbixImport playbook add templates to zabbix.

In the version 1 the host in the inventory are not dynamicaly add to the zabbix cluster.

### Security

During the process of installation, different elements will need root priviledges to be installed correctly.
To secure the root password or sensibles variables we can use an encrypted var_file like the zabbix_mariadb_secured_vars.yml. If needed, the var_file var_file_example.yml contains all the variables used on the repository without values.

### Inventory

The inventory should be defined with the idea of 2 specific parts. On is the zabbix cluster the other is the mariadb cluster. Each part is suppose to be able to work alone, in case of zabbix it would need a local database. So the inventory should reflect this separation idea especialy the existence of variables to define the two groups.
A general version of the inventory will look like this:

```
[zabbix-server]
hostnameZabbixPrimary ansible_host=ip.of.the.host privatekeyfile=/[...]/path/to/key ansible_user=ansible_user_to_connect state=primary isZabbixCluster=True ansible_become_pass='{{ zabbix_master_root_password }}'

[zabbix-server:vars]
ansible_become=yes
ansible_become_method=su

[mariadbCluster]
hostnameMariadbPrimary ansible_host=ip.of.the.host privatekeyfile=/[...]/path/to/key ansible_user=ansible_user_to_connect ansible_become_pass='{{ mariadb_master_root_password }}' lvl=master isZabbixCluster=True state=standby
hostnameMariadbSlave ansible_host=ip.of.the.host privatekeyfile=/[...]/path/to/key ansible_user=ansible_user_to_connect ansible_become_pass='{{ mariadb_slave_root_password }}' lvl=slave isZabbixCluster=False state=notused

[mariadbCluster:vars]
ansible_become=yes
ansible_become_method=su
```

In this generic version, we have 1 zabbix master and 1 standby but we can increase the number of standby by adding the parameter "isZabbixCluster" and the "state" to any server of the group, the variable "isZabbixCluster" can be True or False while the variable "state" can be primary or standby.
The same goes for the mariadb cluster. The variable use to recognise the state of the server in the database cluster is "lvl". This variable can have 2 values, master or slave.

Theoricaly, the number of zabbix standby and mariadb slave can be augmented dynamicaly with the correct use of the parameters "isZabbixCluster" and "lvl" but not the number of zabbix masters nor the number of mariadb masters.
This restriction come from the construction of the roles creating the cluster. zabbix_pacemaker_rhel, mariadb_cluster_keepalived_rhel and mariadb_galeria_rhel need to define all the slaves first (see the example part) and then init a single master but the construction of the role imply the existence of a single master.

### Structure

The structure of the default installation is the following:

![Physic Server Informations .fig 1](documentation/serversInfra.jpg)

The 3 servers are connected to 2 specific networks. First, the frontend accessible to the administrators of zabbix. This frontend is suppose to deliver only the web interface of zabbix. Second, the backend only accessible to the 3 servers. The configurations and cluster work together on this network.
Note that the defined ip are only examples here and can be changed anytime by modifying the local inventory/inventory file.
The figure 2 also show where are physical installed the different services.

The figure 2 is a simple representation of the services and there connections.
The service accessible outside of the backend server should only be zabbix interface through pacemaker virtual ip or directly on the ip of the zabbix servers.

------------------- ![Service relations .fig 2](documentation/servicesInfra.jpg) ------------------