# Role zabbix_mariadb_user_rhel

This role add a zabbix user to a mariadb database. It then add the default zabbix database configuration.
It also partition the database and add default templates.

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html

## Variables to define

* db_user {zabbix database username}
* db_password {zabbix database password}
* virtual_ip_mariadb {ip used to connect to mariadb database or mariadb cluster}
* zabbix_db_name {name of the zabbix database}
* zabbix_db_partition {name of the zabbix partition on the database}

## Behavior

This role add a zabbix user and create a database for zabbix if the database does not already exist.
It use the default zabbix creation script to create the database. The script is related to zabbix 4.0.
Then the role alter tables and add events from the local altering script. The local script alterScript.j2 is first transfered to the server to be completed with ansible vars. Then it is executed to import all the needed events.

### Security

This role alter a mariadb database or mariadb cluster resulting in change in the database and the use of credential to connect to the database.

### Inventory

The role should target a valid mariadb/mysql database so in case the hostgroup is a cluster and not a single server, we should define correctly the master or primary server which will receive the configuration. For example we can use a param like defined here:

```
[mariadbCluster]
hostname_of_the_host ansible_host=ip_of_the_host privatekeyfile=/path/to/key ansible_user=user_to_connect ansible_become_pass='{{ SuperPass }}' lvl=master
hostname_of_the_host2 ansible_host=ip_of_the_host2 privatekeyfile=/path/to/key2 ansible_user=user_to_connect2 ansible_become_pass='{{ SuperPass2 }}' lvl=slave

[mariadbCluster:vars]
ansible_become=yes
ansible_become_method=su
```

If there are multiple master, we should define another param to install the config on a single server of the cluster. The cluster will then propagate the configuration.