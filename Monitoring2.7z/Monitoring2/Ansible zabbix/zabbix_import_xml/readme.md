# Role zabbix_import_xml

This role import a zabbix xml template.
Default ansible module for zabbix import does not allow import of xml. https://docs.ansible.com/ansible/latest/modules/zabbix_template_module.htmld
03-06-2019

## Requirements

The role was developped with ansible 2.7 and will most likely need ansible 2.7 to be run correctly.
For more information regarding the modules used on the role, see the ansible documentation: https://docs.ansible.com/ansible/latest/modules/modules_by_category.html
This role requires an access to the zabbix api. So it needs to be executed on a machin on the same network as the zabbix master ip or zabbix cluster Virtual ip.
It also need the credential to access the zabbix api so a zabbix api user should be defined before executing this role.

## Behavior

This role import zabbix xml templates directly from the role. The templates to import should be defined on tasks/zbx_import.yml by default, they should be placed on the role path. In case of error during the importation, all the template will be shown on the console so you need to go on the zabbix server (the script is not erased if the import fail) and you need to use the script and register the return to see the error. 
Example to do so:
```
# unset http_proxy
# unset https_proxy
# python /tmp/python_import.py -T /tmp/zbx_export_templates.xml -U True -D False >> /[...]/path/to/DebugFile
```

## Variables to define

* virtual_ip_zabbix {zabbix cluster ip}
* zabbix_api {login/user to call zabbix api}
* zabbix_api_pass {password to call zabbix api}

### Security

The script to install zabbix template is defined by hand and needs zabbix api credentials to connect.
The user defined with zabbix_api and zabbix_api_pass need the same right as a zabbix super administrator to connect and import templates.
The User type defined on the web interface should be "Zabbix Super Admin".

### Inventory

No Specific variables needed.
```

[ZabbixTargetHost]
ZabbixPrimary ansible_host=Ip.ofThe.zabbix.target privatekeyfile=[...]/path/to/your/key ansible_user=UserToConnectOnTheTaget

[ZabbixTargetHost:vars]
ansible_become=yes
ansible_become_method=su
ansible_become_pass='{{ ZabbixServerRootPassword }}'

```
