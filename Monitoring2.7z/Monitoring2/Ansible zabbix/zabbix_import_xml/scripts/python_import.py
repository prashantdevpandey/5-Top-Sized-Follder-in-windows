#!/usr/bin/python


#This script allow the installation of xml template on zabbix.
#It take a template as an args of the command line -T and install it on the zabbix server
#

import argparse
import configparser
import sys
import time
from zabbix.api import ZabbixAPI

#https://www.zabbix.com/forum/zabbix-help/51624-zabbix-template-import-command-line-tool-script
#Parser command come from a forum of zabbix. The solution is not usable as defined on the forum but can be transformed to suit the needs.
# Define commandline arguments
parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,description='Imports Zabbix templates from XML files.',epilog="""This program can use .ini style configuration files to retrieve the needed API connection information. To use this type of storage, create a conf file (the default is $HOME/.zbx.conf) that contains at least the [Zabbix API] section and any of the other parameters: [Zabbix API] username=UserNameToUse password=PasswordToUse api=http://zabbixName/zabbix/api_jsonrpc.php no_verify=true""")
parser.add_argument('-T', '--templates', help='List of XML template files to import. Not a repo but #file1.xml+file2.xml',required=True, nargs="+")
parser.add_argument('-U', '--updateExisting', help='If a template already exists in Zabbix, update any changes in template elements. Boolean #True or False',required=True)
parser.add_argument('-D', '--deleteMissing', help='If the element exist on zabbix but not on the template, the element is delete. Boolean #True to delete False to keep all.',required=True)

args = parser.parse_args()

# Zabbix url username and password for connection
URL='http://{{ virtual_ip_zabbix }}/zabbix/api_jsonrpc.php'
USER="{{ zabbix_api }}"
PWD="{{ zabbix_api_pass }}"

#open xml file for reading from the given -T file
# Read the xml template in xml_file
for template in args.templates:
    with open(template) as f:
        xml_file = f.read()
f.close()

update = args.updateExisting #is True or False but as a text
delete = args.deleteMissing #is True or False but as a text

booleanUpdate = ('True' == update) #is now a boolean
booleanDelete = ('True' == delete) #is now a boolean

# Create zabbix object using the ZabbixApi
zabbix_conn_obj=ZabbixAPI(url=URL, user=USER, password=PWD)

#clean up the xml file of newlines and "humain" format
xml_file=xml_file.strip(' \n\t')

#all the expected arguments for the template import are defined on the zabbix web site
#https://www.zabbix.com/documentation/4.0/manual/api/reference/configuration/import

result = zabbix_conn_obj.do_request("configuration.import",{"format": "xml","rules": {
	"applications": {"createMissing": True, "deleteMissing": booleanDelete},
	"discoveryRules": {"createMissing": True, "updateExisting": booleanUpdate, "deleteMissing": booleanDelete},
	"graphs": {"createMissing": True, "updateExisting": booleanUpdate, "deleteMissing": booleanDelete},
	"groups": {"createMissing": True},
	"hosts": {"createMissing": True, "updateExisting": booleanUpdate},
	"httptests": {"createMissing": True, "updateExisting": booleanUpdate, "deleteMissing": booleanDelete},
	"images": {"createMissing": True, "updateExisting": booleanUpdate},
	"items": {"createMissing": True, "updateExisting": booleanUpdate, "deleteMissing": booleanDelete},
	"maps": {"createMissing": True, "updateExisting": booleanUpdate},
	"screens": {"createMissing": True, "updateExisting": booleanUpdate},
	"templateLinkage": {"createMissing": True},
	"templates": {"createMissing": True,"updateExisting": booleanUpdate},
	"templateScreens": {"createMissing": True, "updateExisting": booleanUpdate, "deleteMissing": booleanDelete},
	"triggers": {"createMissing": True, "updateExisting": booleanUpdate, "deleteMissing": booleanDelete},
	"valueMaps": {"createMissing": True, "updateExisting": booleanUpdate}
	},"source": xml_file})

#In case of no visible evolution of the template, it is possible to print the return of the command. This return contain the template and the error associated.
#In case of no return, it usualy means that everything when smoothly
#It is well advised to send the return of the ansible command to a file because of the size of the template imported.
#print(result)
