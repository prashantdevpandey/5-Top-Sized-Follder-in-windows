#!/bin/ksh
#

#================================================================================
# Include common tools
#

. $HOME/monitoring/scripts/gatemonitor_func.sh

#================================================================================
# Functions
#
#--------------------------------------------------------------------------------
# Display how to use command line
#--------------------------------------------------------------------------------
Bad_usage ()
{
 print "Usage : $0 [ -w <minutes> ] [ -s ] [-f <dump file> ]"
 print ""
 print "Description : Checks that the GDS or Reservation Engine Application "
 print "              is running properly"
 print ""
 print " -w     Watch mode, runs $0 every <minutes>, if <minutes> is not "
 print "        specified a default value of 5 minutes will be used."
 print ""
 print " -s     Summerized mode, if no problem have been detected it only shows "
 print "        global application status, if some errors have been found it shows "
 print "        detailled information about the application part were errors occurs"
 print ""
 print " -f     Put a detailled dump of application status into file <dump file>."

}

#--------------------------------------------------------------------------------
# Checks all application parts
#--------------------------------------------------------------------------------
DoChecks ()
{
#--- initialize Global application status
GLOBAL_RETURN_CODE=${OK_RETURN_CODE}

if [ "$MODE" = "SUMMERIZED" ]
then
   printf  "%-76s" "${underline}${bold}$(date '+%Y/%m/%d %H:%M:%S')  CHECKING XFB GATEWAY APPLICATION " 2>/dev/null
fi


for check in CheckApplicationRunning CheckTransferts CheckTcpIp CheckBackupFiles CheckSSHSecureRelay CheckSecureRelay CheckFtp CheckSFtp
do
        #--- Run current check
        eval $check > $LOCAL_ERROR_FILE 2>/dev/null
        LOCAL_RETURN_CODE=$?
        #--- update global return code
        GLOBAL_RETURN_CODE=$(ComputeGobalReturnCode $GLOBAL_RETURN_CODE $LOCAL_RETURN_CODE)
        #--- handle direct display and dump file update
        CMD="cat $LOCAL_ERROR_FILE  $DUMP_CMD $SUMMERIZED_CMD"
#DEBUG
#echo $CMD
        eval $CMD
        #--- if an error occurs update $GLOBAL ERROR_FILE
        [ $LOCAL_RETURN_CODE -ne ${OK_RETURN_CODE} ] && { cat $LOCAL_ERROR_FILE |tee -a $GLOBAL_ERROR_FILE >/dev/null 2>&1 ; }
        #-- stop here if application is not running
        [[ $check = "CheckApplicationRunning"  &&  $LOCAL_RETURN_CODE -ne ${OK_RETURN_CODE}  ]] && { break ; }
done

if [ "$MODE" = "SUMMERIZED" ]
then
        #--- print global status to screen
        printf "%10s\n" "[${ID_CODE[${GLOBAL_RETURN_CODE}]}]${normal}" 2>/dev/null
        #--- If we've errors, print them
        [ -f $GLOBAL_ERROR_FILE ] && { cat $GLOBAL_ERROR_FILE ; }
fi


}

#================================================================================
# MAIN PROCESSING
#================================================================================

#--- Variables initialization
MODE="DETAILLED"
RUN_EVERY=0
LOCAL_ERROR_FILE=/tmp/$(basename $0)_local_err_file.$$
#--- GLOBAL_ERROR_FILE is used only in summarized mode to s
GLOBAL_ERROR_FILE=/tmp/$(basename $0)_global_err_file.$$

#--- Command line arguments parsing
while getopts w:sf: my_opt
do
    case $my_opt in
    w)
        let RUN_EVERY=60*${OPTARG} >/dev/null 2>&1
        [ $? -ne 0 ] && { RUN_EVERY=300 ; }
        ;;
    s)
        MODE="SUMMERIZED"
        #--- SUMMERIZED_CMD will be concatenated to the check command (see DoChecks) to avoid screen printing
        SUMMERIZED_CMD=" 1>/dev/null 2>&1 ; printf '.' 2>/dev/null"
        ;;
    f)
        DUMP_FILE=$OPTARG
        [ -f $DUMP_FILE ] && { rm -f $DUMP_FILE ; }
        #--- DUMP_CMD will be concatenated to the check command (see DoChecks) to update the dump file
        DUMP_CMD="| tee -a $DUMP_FILE"
        ;;
    \?)
        Bad_usage "Invalid option"
        exit $ERROR_RETURN_CODE;;
    esac
done

#DEBUG
#echo "->$RUN_EVERY,$MODE,$SUMMERIZED_CMD,$DUMP_FILE,$DUMP_CMD"

#--- let's check the application
while [ 1 -eq 1 ]
do
        #--- clean temporary files
        [ -f $LOCAL_ERROR_FILE ]  && { rm -f $LOCAL_ERROR_FILE ; }
        [ -f $GLOBAL_ERROR_FILE ] && { rm -f $GLOBAL_ERROR_FILE ; }

        #--- Run all checks
        DoChecks

        #--- What should we do now
        if [ $RUN_EVERY -eq 0 ]
        then
                #--- run only once, so stop looping...
                break
        else
                #--- sleep a while before next check
                sleep $RUN_EVERY
        fi
done

#--- clean temporary files
[ -f $LOCAL_ERROR_FILE ]  && { rm -f $LOCAL_ERROR_FILE ; }
[ -f $GLOBAL_ERROR_FILE ] && { rm -f $GLOBAL_ERROR_FILE ; }

#--- return application global status
exit $GLOBAL_RETURN_CODE
