# xfb

xfb process and monitoring verification