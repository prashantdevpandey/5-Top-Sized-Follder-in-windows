import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.management.ObjectName as ObjectName;
import java.lang.management.ManagementFactory;
import subprocess
import sys, cmd, socket, optparse
from urlparse import urljoin
from cmd import Cmd
from java.lang import String
from jarray import array
from javax.management.remote import JMXConnector
import ConfigParser
import json
import getopt

global CONFIG_FILE
global JSON
global JSON_SUP
global flag
global RRD_BASE
global CMD
def manage_flag(val):
        return 2 if val == 2 else  1
try:
    opts, args = getopt.getopt(sys.argv[1:], "c:j:s", ["configuration=", "json=", "supervision=" ])
    for o, a in opts:
        if o in ("-c", "--configuration"):
            CONFIG_FILE = a
        elif o in ("-j", "--json"):
            JSON = a
        elif o in ("-s", "--supervision"):
            JSON_SUP = a
except getopt.GetoptError as err:
    print "&redFailed to parse argument " + str(err)
    sys.exit(2)

try:
        config = ConfigParser.ConfigParser()
        config.read(CONFIG_FILE)
        serverUrl=config.get("GLOBAL", "serverUrl")
        username=config.get("GLOBAL","username")
        password=config.get("GLOBAL","password")
        port=config.get("GLOBAL","port")
        XYMON=config.get("GLOBAL","XYMON")
        XYMONSRV=config.get("GLOBAL","XYMONSRV")
        SRV=config.get("GLOBAL","SRV")
except:

        print '&redERROR CODE 2  check your configuration file....\n',sys.exc_info()[0]
        sys.exit(2)
try:
    credentials = array([username,password],String)
    environment = {JMXConnector.CREDENTIALS:credentials}
    url = javax.management.remote.JMXServiceURL('service:jmx:rmi:///jndi/rmi://'+serverUrl+':'+str(port)+'/jmxrmi')
    connector = javax.management.remote.JMXConnectorFactory.connect(url,environment);
    global remote
    remote = connector.getMBeanServerConnection();
except:
    print "&redFailed to connect on server " + serverUrl  + " on the port "  + str(port) + " with user " + username
    sys.exit(2)
try:
    json_data=open(JSON).read()
    data=json.loads(json_data)
except:
        print "&redFailed to parse JSON " + JSON
        sys.exit(2)
try:
    json_sup=open(JSON_SUP).read()
    data_sup=json.loads(json_sup)
except :
        print "&redFailed to parse JSON " + JSON_SUP
        sys.exit(2)
flag = 0
print "<h1><B>" + data['type'] + " status</B></h1>"
print "</br>"
try:
    obn = javax.management.ObjectName('java.lang:type=Runtime')
    result = remote.getAttribute(obn, 'Name')
    print "<u><B>Global Information :</B></u></br>"
    print "<I>Hostname is :</I> " + result.split('@')[1]
    print "<I>PID is: </I> " + result.split('@')[0]
    obn = javax.management.ObjectName('java.lang:type=Runtime')
    result = remote.getAttribute(obn, 'InputArguments')
    print "</br><I>Java option :</I>"
    print "<pre>"
    for arg in result:
        print arg
    print "</pre>"
except:
    print "&redFailed to get PID of service"
    sys.exit(2)




for query in data['queries']:
    print "</br><hr></br>"
    print "<h2><u>" + query['object'] + "</h2></u>"
    print "<table BORDER='1' >"
    print "<tr>"
    print "<th>Objects</th>"
    for attr in query['attributes']:
        print "<th>"+attr['name']+"</th>"
    print "</tr>"
    mb = query['object']
    TEST = remote.queryMBeans(ObjectName(mb),None)
    if len(TEST) == 0:
        COLOR='&red'
        flag=2
        print "<td>" + COLOR + mb + "</td>"
    else:
        COLOR='&green'
        for obj in remote.queryMBeans(ObjectName(mb),None):
            mbean=str(obj.getObjectName())
            print "<tr>"
            print "<td>" + COLOR + mbean.split('=')[-1] + "</td>"
            for attr in query['attributes']:
                attribute=attr['name']
                obn = javax.management.ObjectName(mbean)
                result = remote.getAttribute(obn, attribute)
                try:
                    final_result=result.get(attr['key'])
                    attribute = attribute + " " + attr['key']
                except:
                     final_result = result
                try:
                    color = '&clear'
                    RRD_BASE="NONE"
                    for supervision_rule in data_sup[data['type']]:
                        if supervision_rule == mbean.split('=')[-1]:
                            if attr['key'] == data_sup[data['type']][supervision_rule][attr['name']]['name']:
                                if long(final_result) > long(data_sup[data['type']][supervision_rule][attr['name']]['crit']):
                                    color='&red'
                                    flag=2
                                elif long(final_result) > long(data_sup[data['type']][supervision_rule][attr['name']]['warn']):
                                    color='&yellow'
                                    flag=manage_flag(flag)
                                else:
                                    color='&green'
                except Exception as e:
                    print sys.exc_info()[0]
                    print e
                    color='unset'
                if color == 'unset':
                    print "<td>" + str(final_result) + "</td>"
                else:
                    print "<td>" +  color + str(final_result) + "</td>"
                if not mbean.split('=')[-1] == 'Runtime':
                    if final_result is not str:
                       RRD = "specif_http_"+mbean.split('=')[-1].replace('/','').replace(' ','_')+","+attr['name']
                       RRD_BASE = "specif_http_"+mbean.split('=')[-1].replace('/','').replace(' ','_')+",*"
                       NAME = data['type']+"_"+mbean.split('=')[-1].replace('/','').replace(' ','_')
                       CMD = XYMON + " "  + XYMONSRV +" \"data "+ SRV +".trends \n["+RRD+".rrd]\n" +"DS:response_time:GAUGE:600:0:U " + str(final_result) + "\""
                       subprocess.call(CMD , shell=True)
            print "</tr>"
    print "</table>"         
    if not RRD_BASE == "NONE":
        print "<GRAPH id=\"GRAPH\" graph_type=\"specif_http\" graph_datasource=\""+RRD_BASE+"\" title=\""+NAME+"\"></GRAPH>"
sys.exit(int(flag))

