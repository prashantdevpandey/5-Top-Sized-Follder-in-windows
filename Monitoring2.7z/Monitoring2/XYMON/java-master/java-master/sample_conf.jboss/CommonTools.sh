#!/bin/bash

#-----------------------------------------------------------
#       VERSIONS
#----------------------------------------------------------
# XX/XX/2016 - BBT - NEW
# 25/08/2017 - TJY - send_xymon_graph ajout host $4
# 18/01/2018 - TJY - send_xymon_notify

function convert_size {
        i=$((${#_LOG_SIZE}-1))
        case ${_LOG_SIZE:$i:1} in
                M)
                        _MAX_SIZE_IN_BYTES=$(( ${_LOG_SIZE:0:$i} * 1048576))
                        ;;
                K)
                        _MAX_SIZE_IN_BYTES=$(( ${_LOG_SIZE:0:$i} * 1024))
                        ;;
                O)
                        _MAX_SIZE_IN_BYTES=${_LOG_SIZE:0:$i}
                        ;;
                G)
                        _MAX_SIZE_IN_BYTES=$(( ${_LOG_SIZE:0:$i} * 1073741824))
                        ;;
                *)
                        exit_script "ERROR UNIT OF LOG _LOG_SIZE IS NOT VALID ${_LOG_SIZE:$i:1}" 2
                        ;;
        esac
}
function read_json {
        TYP=$1
        KEY=$2
        VALUE=$(python ${_SCRIPTPATH}/print_json.py $TYP $KEY $JSON)
        echo $VALUE | python -m json.tool 2&>1 > /dev/null
        if [[ $? -ne 0 ]]
        then
                echo $VALUE
        fi
}
function send_xymon_alert {
        date
        (echo "status $MACHINE.$SONDE_NAME $COLOR $(date) ";$CAT $OUT) | $XYMON $XYMSRV "@"
}
function send_xymon_graph {
RRD=$1
GRAPH=$2
GRAPH_VALUE=$3
SRV=${4:-$MACHINE}
$XYMON $XYMSRV "data $SRV.trends
[${RRD}.rrd]
DS:${GRAPH}:GAUGE:600:0:U $GRAPH_VALUE"
}
function send_xymon_notify {
CERT=$1
RESSOURCE=$2
EXP_DAYS=$3
EXP_DATE=$4
$XYMON $XYMSRV "notify $MACHINE.$SONDE_NAME Expiration Certificat ${CERT}
${RESSOURCE}
${CERT} expire in ${EXP_DAYS} days (${EXP_DATE}) ask SSG to generate a CSR"
}
function log {
LOG_LEVEL=$1
FROM=$2
MSG=$3
: ${FROM?}  ${MSG?} ${LOG_LEVEL?} ${_LOG_LEVEL}
if test  ${_LOG_LEVEL[$LOG_LEVEL]} -ge ${_LOG_LEVEL[$_LEVEL]}
then
        SIZE_OF_CURRENT_LOG=$(stat --format=%s $_LOG_FILE)
        if test $SIZE_OF_CURRENT_LOG -gt $_MAX_SIZE_IN_BYTES
        then
                i=$(($_LOG_ROTATION - 1))
                while test $i -ge 1
                do
                        test -f ${_LOG_PATH}/archive/${_LOG_NAME}.log.$i && cp  ${_LOG_PATH}/archive/${_LOG_NAME}.log.$i  ${_LOG_PATH}/archive/${_LOG_NAME}.log.$(($i + 1 ))
                        i=$(($i - 1))
                done
                cp $_LOG_FILE ${_LOG_PATH}/archive/${_LOG_NAME}.log.1
                > $_LOG_FILE
                echo "$(date '+%d-%m-%Y %H:%M:%S') [$LOG_LEVEL] [$_HOST] [$FROM] $MSG" >> $_LOG_FILE
        else
                echo "$(date '+%d-%m-%Y %H:%M:%S') [$LOG_LEVEL] [$_HOST] [$FROM] $MSG" >> $_LOG_FILE
        fi
fi
}
function exit_script {
        MSG=${1:-"Unknown Error"}
        ERROR_CODE=${2:-"1"}

        if test $ERROR_CODE -eq 2
        then
                echo "CRITICAL" ${FUNCNAME} "${MSG}"
        elif test $ERROR_CODE -eq 1
        then
                log "CRITICAL" ${FUNCNAME} "${MSG}"
        else
                log "INFO" ${FUNCNAME} "${MSG}"
        fi
        exit $ERROR_CODE
}
function PURGE {
        rm -rf $OUT
        test -f $_ID_LINE && rm -f $_ID_LINE
        test -f $JSON && rm -f $JSON
        test -f $JSON_FOR && rm -f $JSON_FOR
        test -f $JSON_OLD && rm -f $JSON_OLD
        test -f $JSON_OLD_FOR && rm -f $JSON_OLD_FOR
        #
        #HERE PURGE YOUR TEMP FILE
        #
}
export -f PURGE
export -f exit_script
export -f log
export -f convert_size
export -f read_json
export -f send_xymon_alert
export -f send_xymon_graph
export -f send_xymon_notify
