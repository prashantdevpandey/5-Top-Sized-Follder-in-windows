# Monitoring Script of Java Virtual Machine

To put in place the script: 
## 1. Copy
 - ```xy-java.sh``` monitoring script
 - ```CommonTools.sh```
	standard tools of middleware monitoring script
 - ```CommonConf.sh```
	common configuration for all script on the server
 - ```get_JMX.py```
    Python script to ask JVM
 - ```jython-standalone-2.7.0.jar```
    Jython JAR file

## 2. Local prerequisite
 - ```${JAVA_APPLICATION_SERVER}.json```
    internal schema 
 - ```${JAVA_APPLICATION_SERVER}_config.json```
    configuration for the connection of the script 
 - ```${JAVA_APPLICATION_SERVER}_threshold.json```
    thresold linked to internal schema 

## 3. Tune CommonConf
 - Name of the Java Application server

```bash 
JAVA_SONDE_NAME=${JAVA_APPLICATION_SERVER}
```

 - Connexion information 

```bash 
SRV=127.0.0.1
PORT=1099
```
 - JSON config
 
```bash
SCHEMA_JSON=${_SCRIPTPATH}/${JAVA_APPLICATION_SERVER}.json
SUP_JSON=${_SCRIPTPATH}/${JAVA_APPLICATION_SERVER}_threshold.json
CONF_JSON=${_SCRIPTPATH}/${JAVA_APPLICATION_SERVER}_config.json
```

## 4. Enable Xymon schedule
Edit ```~xymon/etc/clientlaunch.cfg``` and add the following block for each probe implemented (replace ```$PROBE``` by your script name): 

```bash 
[$PROBE]
    ENVFILE $XYMONCLIENTHOME/etc/xymonclient.cfg
    CMD $XYMONCLIENTHOME/ext/xy-$PROBE.sh
    LOGFILE $XYMONCLIENTLOGS/xy-$PROBE.log
    INTERVAL 5m
```
