#!/bin/bash
_CRIT_CPU=90
_WAR_CPU=80
_CRIT_MEM=90
_WAR_MEM=80
_HOST=$1
_SCRIPT=$(readlink -f $0)
_NAME=$(basename $_SCRIPT)
_SCRIPTPATH=$(dirname $_SCRIPT)
#
#XYMON
#
color_None=clear
color_Ok=green
color_Warn=yellow
color_Err=red
export COLOR=$color_Ok
XYMON=/opt/xymon/client/bin/xymon
if [[  "${XYMSRV}X" == "X"   ]]
then
        XYMSRV=xymon.ipa.cloud.sbs.local
        MACHINE=$(hostname -s)
fi

CAT=cat

#
#CURL
#
_CURL_OPT='-L -k -1 -w "rc:%{http_code}:connect:%{time_connect}:transfert:%{time_starttransfer}:stats:%{time_total}"'
_CURL_CMD="curl --max-time 60 -s"

#
#LOGS
#
_LEVEL=DEBUG
_MAX_SIZE_IN_BYTES=0
_LOG_SIZE="100 K"
_LOG_ROTATION=5
_LOG_NAME=${_NAME%.*}
_LOG_FILE=${_SCRIPTPATH}/../logs/${_LOG_NAME}.log
declare -A _LOG_LEVEL=( ["CRITICAL"]=50 ["ERROR"]=40 ["WARNING"]=40 ["INFO"]=20  ["DEBUG"]=10)

#
## SONDES APPLICATIVES
#

#
#JAVA - TOMCAT
#
JAVA_SONDE_NAME=tomcat
SRV=127.0.0.1
PORT=1099
SCHEMA_JSON=${_SCRIPTPATH}/tomcat.json
SUP_JSON=${_SCRIPTPATH}/tomcat_threshold.json
CONF_JSON=${_SCRIPTPATH}/tomcat_config.json

# Couleur du resultat
TX_COLOR="grey"
