#!/bin/bash
#-----------------------------------------------------------
#
#VERSIONS
#
#----------------------------------------------------------
# 00/00/2018 - BBT - creation du script
# 20/11/2018 - TJY - Mise a jour pour jboss
# 18/12/2018 - TJY - JAVA_SONDE_NAME
VERSION="18/12/2018"
#-----------------------------------------------------------
#
#INIT VAR
#
#----------------------------------------------------------
_HOST=$(hostname)
_SCRIPT=$(readlink -f $0)
_NAME=$(basename $_SCRIPT)
_SCRIPTPATH=$(dirname $_SCRIPT)
source ${_SCRIPTPATH}/CommonConf.sh
test -d $_LOG_FILE || mkdir -p ${_SCRIPTPATH}/log/archive
test -f $_LOG_FILE || touch $_LOG_FILE
source ${_SCRIPTPATH}/CommonTools.sh
: ${_LOG_SIZE?"Log size not defined"}  ${_LOG_ROTATION?"Log file rotation not defined"} ${_LEVEL?"Log level is not defined"}  ${_HOST?"Host is missing"}
trap PURGE EXIT
convert_size
#----------------------------------------------------------
#                       SCRIPT  BEGIN HERE
#----------------------------------------------------------
SONDE_NAME=$JAVA_SONDE_NAME
OUT=/tmp/sup_global.out_$$

# HEADER
echo "-- Check $_SCRIPT Version $VERSION --" > $OUT

log 'DEBUG' 'INIT' "$TEST $MACHINE $XYMSRV"
#
#IHM TEST
#
java -jar ${_SCRIPTPATH}/jython-standalone-2.7.0.jar   ${_SCRIPTPATH}/get_JMX.py --configuration $CONF_JSON --json $SCHEMA_JSON   --supervision $SUP_JSON >> $OUT
RET=$?
if [[ $RET -eq 0 ]]
then
        COLOR=$color_Ok
elif [[ $RET -eq 1 ]]
then
   	COLOR=$color_Warn
elif [[ $RET -eq 2 ]]
then
        COLOR=$color_Err
else
   	COLOR=$color_Err
fi
send_xymon_alert