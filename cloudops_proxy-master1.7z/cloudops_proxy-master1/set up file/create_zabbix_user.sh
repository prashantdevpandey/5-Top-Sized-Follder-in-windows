#!/bin/bash

sudo -i useradd -m --password zabbix zabbix
sudo -i groupadd zabbix
sudo -i mkdir -m 700 /home/zabbix/.ssh/
echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCX610H7ye+Kh4kl2JLKlM37SCYI6bJOdEWG7d50gI60UVl77ltTipLtq+nc3DrxT9OobiEgVUrWKjPUpMVHu6iAiE7F/rUJxUzWgbHRVBCXIVb60DsvvmHGhfPXxYCgwn7KDc+fEy4onM8x5o1mJP0l73cQI7NqreeDObMagA4c9LskFezDxZwLWVFQLrEYqxV9O9xsnpZIjjyHyJwYWYIlBLGCtmqwAGMz/4KOYQsvFaeQhCFh1/X1Cefg0KJxnncG2mR0CLsX9wWe9R4RCRd5rkwuPXARjmUK0PGQMJ6ndlrXOB9gWYUidXcxzZ64LRYxg9uDlMt57cKR3jdFXSV" | sudo -i tee -a /home/zabbix/.ssh/authorized_keys
sudo -i chown -R zabbix:zabbix /home/zabbix/.ssh/
echo 'zabbix ALL=(ALL) NOPASSWD:ALL' | sudo -i tee /etc/sudoers.d/zabbix
sudo -i chmod 440 /etc/sudoers.d/zabbix
