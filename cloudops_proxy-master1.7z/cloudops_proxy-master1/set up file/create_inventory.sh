#!/bin/bash
#Author Blazej Michalczyk 2018

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Remove previous inventory data
rm -f "/usr/lib/zabbix/externalscripts/agent_automation/install_agent/inventory"


echo "[agent]" > /usr/lib/zabbix/externalscripts/agent_automation/install_agent/inventory

IDs=$(aws ec2 describe-instances --filters "Name=tag:SSG-AGENT,Values=YES" --query "Reservations[].Instances[].InstanceId" --output text)
                for line in $IDs; do

                                        InstanceId=$line
                                        ImageId=$(aws ec2 describe-instances --instance-id "$line" --query "Reservations[].Instances[].ImageId" --output text)
                                        PrivateIpAddress=$(aws ec2 describe-instances --instance-id "$line" --query "Reservations[].Instances[].PrivateIpAddress" --output text)

                                        echo "$PrivateIpAddress inventory_hostname=$InstanceId ec2_image_id=$ImageId ec2_private_ip_address=$PrivateIpAddress ec2_id=$InstanceId" >> /usr/lib/zabbix/externalscripts/agent_automation/install_agent/inventory


                                done
