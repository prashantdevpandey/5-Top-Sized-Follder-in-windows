#!/bin/bash

ip=$1

if nc -z -w2 $ip 10050 2>/dev/null; then
  echo "ok"
  exit 0
else
  echo "nok"
  exit 1
fi
