#!/bin/bash

while [[ $# > 1 ]]

do
    key="$1"

    case $key in
            -h|--host)
            INSTANCE="$2"
            shift # past argument
        ;;
            *)
            # unknown option
        ;;
    esac
    shift # past argument or value
done

IPs=$(aws ec2 describe-instances --output=json --instance-id ${INSTANCE} --query "Reservations[].Instances[].NetworkInterfaces[].PrivateIpAddresses[].PrivateIpAddress" --output text)

for line in $IPs; do
    if nc -z -w2 $line 22 2>/dev/null; then
        echo $line
        exit 0
    #else
        #echo "no connection"
    fi
done
