#!/bin/bash

session=$(aws sts get-session-token --duration-seconds 900 | jq -r '.[] | .SessionToken')

cp ec2.ini.template ec2.ini
echo "aws_security_token = $session" >> ec2.ini

ansible-playbook master.yml -i ec2.py 2>> ansible_log.err
