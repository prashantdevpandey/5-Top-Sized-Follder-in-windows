#!/bin/bash

session=$(aws sts get-session-token --duration-seconds 900 | jq -r '.[] | .SessionToken')

cp ec2.ini.template ec2.ini
echo "aws_security_token = $session" >> ec2.ini

python ec2.py --refresh-cache
