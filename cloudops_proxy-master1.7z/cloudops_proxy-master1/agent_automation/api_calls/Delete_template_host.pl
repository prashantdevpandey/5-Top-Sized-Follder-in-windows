#!/usr/bin/perl

# This script updates, or creates the agent in the Zabbix server
# first argument is the hostname (insrance id)
# second argument is the private ip of the host 
# third argument is the group id of the group containing the host
# fourth argument is the template id of the template used by the host
# fifth argument is the proxy host id

use strict;
use JSON::RPC::Client;
use utf8;
use Data::Dumper;
use constant {
    SETENV_FILE=>'setenv.conf',
    AGENT_PORT=>10050,
    SNMP_PORT=>161
};

my %SETENV;
BEGIN {
 open (my $fhSetEnv,'<',substr($0,0,rindex($0,'/')).'/'.SETENV_FILE) || die 'Cant set environment: '.SETENV_FILE.' not found!';
 %SETENV=map { chomp; $_=~m/^\s*(?<KEY>[A-Za-z0-9_-]+)\s*=\s*(?:(?<QUO>['"])(?<VAL>[^\g{QUO}]+?)\g{QUO}|(?<VAL>[^'"[:space:]]+?))\s*$/?($+{'KEY'},$+{'VAL'}):('NOTHING','NOWHERE') } grep { $_ !~ m/^\s*(?:#.*)?$/ } <$fhSetEnv>;
 close($fhSetEnv);
}

die 'You must specify ZBX_URL in your config '.SETENV_FILE unless my $url=$SETENV{'ZBX_URL'};
die 'You must specify ZBX_LOGIN in your config '.SETENV_FILE unless my $user=$SETENV{'ZBX_LOGIN'};
die 'You must specify ZBX_PASS in your config '.SETENV_FILE unless my $pass=$SETENV{'ZBX_PASS'};

my $client = new JSON::RPC::Client;

# check connectivity and get authentication token
my $json = {
    jsonrpc => "2.0",
    method => "user.login",
    params => {
        user => $user,
        password => $pass,
    },
    id => 1
};

my $response = $client->call($url, $json);
if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

my $authID = $response->content->{'result'};

# trying to get host
my $json = {
    jsonrpc => '2.0',
    method => 'host.get',
    params => {
        filter => {
            host => [
                @ARGV[0]
            ]
        }
    },
    id => 1,
    auth => "$authID",
};

$response = $client->call($url, $json);
if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

my $fetched_instance = $response->content->{'result'}[0];

if ($fetched_instance)
{
    my @templateids = split(',', @ARGV[1]);

    # unlink previous templates, change interface IP and assign to new groups
    # (cannot change interface when template is linked to the interface)
    my $hostid = $fetched_instance->{'hostid'};
    my $json = {
        jsonrpc => '2.0',
        method => 'host.update',
        params => {
            "hostid" => $hostid,
            "templates_clear" => \@templateids,
        },
        id => 1,
        auth => "$authID",
    };
    $response = $client->call($url, $json);
    if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

    print "host_updated";
}
