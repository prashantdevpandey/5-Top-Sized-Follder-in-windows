#!/usr/bin/perl

use strict;
use JSON::RPC::Client;
use utf8;
use constant {
    SETENV_FILE=>'setenv.conf',
    AGENT_PORT=>10050,
    SNMP_PORT=>161
};

my %SETENV;
BEGIN {
 open (my $fhSetEnv,'<',substr($0,0,rindex($0,'/')).'/'.SETENV_FILE) || die 'Cant set environment: '.SETENV_FILE.' not found!';
 %SETENV=map { chomp; $_=~m/^\s*(?<KEY>[A-Za-z0-9_-]+)\s*=\s*(?:(?<QUO>['"])(?<VAL>[^\g{QUO}]+?)\g{QUO}|(?<VAL>[^'"[:space:]]+?))\s*$/?($+{'KEY'},$+{'VAL'}):('NOTHING','NOWHERE') } grep { $_ !~ m/^\s*(?:#.*)?$/ } <$fhSetEnv>;
 push @INC,split(/\;/,$SETENV{'PERL_LIBS'}) if $SETENV{'PERL_LIBS'};
 close($fhSetEnv);
}

if (@ARGV[0] eq "-h" || @ARGV[0] eq "--help")
{
    print("Usage: Test_api_call.pl host_name new_ip\n");
    exit 1;
}

die 'You must specify ZBX_URL in your config '.SETENV_FILE unless my $url=$SETENV{'ZBX_URL'};
die 'You must specify ZBX_LOGIN in your config '.SETENV_FILE unless my $user=$SETENV{'ZBX_LOGIN'};
die 'You must specify ZBX_PASS in your config '.SETENV_FILE unless my $pass=$SETENV{'ZBX_PASS'};

my $client = new JSON::RPC::Client;

# check connectivity and get authentication token
my $json = {
    jsonrpc => "2.0",
    method => "user.login",
    params => {
        user => $user,
        password => $pass,
    },
    id => 1
};

my $response = $client->call($url, $json);
if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

my $authID = $response->content->{'result'};

print $authID;
