#!/usr/bin/perl

# This script updates, or creates the agent in the Zabbix server
# first argument is the hostname (insrance id)
# second argument is the private ip of the host 
# third argument is the group id of the group containing the host
# fourth argument is the template id of the template used by the host
# fifth argument is the proxy host id

use strict;
use JSON::RPC::Client;
use utf8;
use Data::Dumper;
use constant {
    SETENV_FILE=>'setenv.conf',
    AGENT_PORT=>10050,
    SNMP_PORT=>161
};

my %SETENV;
BEGIN {
 open (my $fhSetEnv,'<',substr($0,0,rindex($0,'/')).'/'.SETENV_FILE) || die 'Cant set environment: '.SETENV_FILE.' not found!';
 %SETENV=map { chomp; $_=~m/^\s*(?<KEY>[A-Za-z0-9_-]+)\s*=\s*(?:(?<QUO>['"])(?<VAL>[^\g{QUO}]+?)\g{QUO}|(?<VAL>[^'"[:space:]]+?))\s*$/?($+{'KEY'},$+{'VAL'}):('NOTHING','NOWHERE') } grep { $_ !~ m/^\s*(?:#.*)?$/ } <$fhSetEnv>;
 close($fhSetEnv);
}

die 'You must specify ZBX_URL in your config '.SETENV_FILE unless my $url=$SETENV{'ZBX_URL'};
die 'You must specify ZBX_LOGIN in your config '.SETENV_FILE unless my $user=$SETENV{'ZBX_LOGIN'};
die 'You must specify ZBX_PASS in your config '.SETENV_FILE unless my $pass=$SETENV{'ZBX_PASS'};

my $client = new JSON::RPC::Client;

# check connectivity and get authentication token
my $json = {
    jsonrpc => "2.0",
    method => "user.login",
    params => {
        user => $user,
        password => $pass,
    },
    id => 1
};

my $response = $client->call($url, $json);
if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

my $authID = $response->content->{'result'};

# trying to get host
my $json = {
    jsonrpc => '2.0',
    method => 'host.get',
    params => {
        "selectInterfaces" => [
            "ip"
        ],
        filter => {
            host => [
                @ARGV[0]
            ]
        }
    },
    id => 1,
    auth => "$authID",
};

$response = $client->call($url, $json);
if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

my $fetched_instance = $response->content->{'result'}[0];

# Instance not found on Zabbix server
if (!$fetched_instance)
{
    print "new_host";
}
# case where the instance is found, AND the ip given as parameter is the same as the
# one registered as interface for the instance in Zabbix Server (we do nothing)
elsif ($fetched_instance->{'interfaces'}[0]->{'ip'} eq @ARGV[1])
{
    print "nothing_to_do";
}
# case where the instance is found, but the ip given is different of the one registered
# as interface, we change it
else
{
    my $hostid = $fetched_instance->{'hostid'};

    my $json = {
        jsonrpc => '2.0',
        method => 'hostinterface.get',
        params => {
            "output" => "extend",
            "hostids" => "$hostid",
        },
	id => 1,
        auth => "$authID",
    };

    $response = $client->call($url, $json);

    if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}

    my $interface_id = $response->content->{'result'}[0]->{'interfaceid'};

    my $json = {
        jsonrpc => '2.0',
        method => 'hostinterface.update',
        params => {
            "interfaceid" => $interface_id,
            "ip" => "@ARGV[1]",
        },
        id => 1,
        auth => "$authID",
    };
    $response = $client->call($url, $json);
    if (!$response->is_success) {die "ERROR!!! ".$response->content->{error}->{data}."\n"}
    
    print "host_updated";
}
