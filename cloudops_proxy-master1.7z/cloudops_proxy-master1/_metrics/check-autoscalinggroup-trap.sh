#!/bin/bash

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Extracting parameters
while [[ $# > 1 ]]
do
        key="$1"
        case $key in
                        -m|--metric-name)
                        METRICNAME="$2"
                        shift # past argument
                ;;
                        -p|--period)
                        PERIOD="$2"
                        shift # past argument
                ;;
                        -n|--namespace)
                        NAMESPACE="$2"
                        shift # past argument
                ;;
                        -s|--statistics)
                        STATISTICS="$2"
                        shift # past argument
                                ;;
                        -d|--dimensions)
                        DIMENSIONS="$2"
                        shift # past argument
                                ;;
                        *)
                        # unknown option
                ;;
        esac
        shift # past argument or value
done
#sleep $[ ( $RANDOM % 30 )  + 1 ]s

VALUE=`aws cloudwatch get-metric-statistics --metric-name ${METRICNAME} --start-time $(date --iso-8601=seconds -d "-10 minutes") --end-time $(date --iso-8601=seconds) --period ${PERIOD} --namespace ${NAMESPACE} --statistics ${STATISTICS} --dimensions Name=AutoScalingGroupName,Value="${DIMENSIONS}" --output=json`


 /usr/bin/zabbix_sender -z 127.0.0.1 -s "${DIMENSIONS}" -k ${METRICNAME} -o "${VALUE}"
echo $? "Time: ${end} Metric: ${METRICNAME} Namespace: ${NAMESPACE} Statistics: ${STATISTICS} Instance: ${DIMENSIONS}" >> $LOG_DIR/check-autoscalinggroup.log

echo ${VALUE}

exit 0

