#!/bin/bash
#Author Blazej Michalczyk 2018

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Extracting parameters
while [[ $# > 1 ]]
do
        key="$1"
        case $key in
                        -h|--hostgroup)
                        HOSTGROUP="$2"
                        shift # past argument
                ;;
                    *)
                        # unknown option
                ;;
        esac
        shift # past argument or value
done

#Remove previous data about hosts
rm -f "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt"

#Get list of hosts from API
perl /usr/lib/zabbix/externalscripts/_api/get-hosts.pl "${HOSTGROUP}"

#Parse list and disable monitoring

#Check if EC2 =====================================================================================================================================
if echo "$HOSTGROUP" | grep "EC2"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws ec2 describe-instances --instance-id "$line" --query "Reservations[].Instances[].Monitoring" --output json)
                                if echo "$STATUS" | grep "State"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_EC2_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.ec2.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo $line
                                fi
done

#Check if RDS =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "RDS"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].OptionGroupMemberships" --output json)
                                if echo "$STATUS" | grep "Status"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_RDS_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done

#Check if AutoScalingGroup =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "AutoScalingGroup"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws autoscaling describe-auto-scaling-groups --auto-scaling-group-names "$line" --query "AutoScalingGroups[]" --output json)
                                if echo "$STATUS" | grep "AutoScalingGroupARN"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_AUTOSCALINGGROUP_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.autoscalinggroup.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done


#Check if DynamoDB =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "DynamoDB"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws dynamodb describe-table --table-name "$line" --output=json --query "Table")
                                if echo "$STATUS" | grep "TableArn"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_DYNAMODB_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.dynamodb.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done

#Check if ECS =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "ECS"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws ecs describe-clusters --clusters "$line" --query "clusters[]")
                                if echo "$STATUS" | grep "status"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_ECS_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.ecs.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done

#Check if ELB =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "ELBv2"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws elbv2 describe-load-balancers --names "$line" --query "LoadBalancers[]")
                                if echo "$STATUS" | grep "LoadBalancerArn"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_ELBv2_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.elb.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done

#Check if ELB_CLASSIC =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "ELB_CLASSIC"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws elb describe-load-balancers --load-balancer-name "$line" --query "LoadBalancerDescriptions[]")
                                if echo "$STATUS" | grep "LoadBalancerName"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_ELBCLASSIC_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.elbclassic.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done


#Check if REDSHIFT =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "REDSHIFT"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws redshift describe-clusters --cluster-identifier "$line" --query "Clusters[]")
                                if echo "$STATUS" | grep "MasterUsername"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_REDSHIFT_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.redshift.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done

#Check if AppStream =====================================================================================================================================
elif echo "$HOSTGROUP" | grep "AppStream"; then

cat "/usr/lib/zabbix/externalscripts/hosts/host_${HOSTGROUP}.txt" | while read line
do
                STATUS=$(aws appstream describe-fleets --names "$line" --query "Fleets[]")
                                if echo "$STATUS" | grep "DisplayName"; then
                                        echo "Instance $line exist on AWS"
                                else
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl "$line" 0
                                        perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl "$line" 1
                                        perl /usr/lib/zabbix/externalscripts/_api/update-one-group.pl "$line" $Group_APPSTREAM_TERMINATED
                                        /usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.AppStream.aws.terminated -o "$line"
										echo "Time: $(date --iso-8601=seconds) Terminated discovery for $HOSTGROUP - $line" >> $LOG_DIR/discover-aws-terminated.log
                                                                                echo "$line"
                                fi
done


#No groups match
else
echo "Wrong group name"
fi

exit 0
