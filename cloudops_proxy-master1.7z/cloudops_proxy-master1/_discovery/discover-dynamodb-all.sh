#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Clean variables
unset VALUE

IDs=$(aws dynamodb list-tables --query "TableNames[]" --output text)
                for line in $IDs; do
                        perl /usr/lib/zabbix/externalscripts/_api/add-host.pl $line $Group_DYNAMODB $Template_DynamoDB $PROXY_ID
                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-dynamodb.log
                        VALUE=${VALUE}"; "$line
                done

/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.dynamodb.check -o "${VALUE}"
echo ${VALUE}

exit 0
