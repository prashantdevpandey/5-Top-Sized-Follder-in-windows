#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#SSG-AGENT Interface change WIN**************************************************************

#Remove previous data about hosts
rm -f "/usr/lib/zabbix/externalscripts/hosts/hostid_agent_yes_win.txt"
rm -f "/usr/lib/zabbix/externalscripts/hosts/hostid_agent_yes_lin.txt"

#SSG-AGENT=YES
IDs=$(aws ec2 describe-instances --filters "Name=tag:SSG-AGENT,Values=YES" --query "Reservations[].Instances[].InstanceId" --output text)
                for line in $IDs; do

#Check platform
Platform=$(aws ec2 describe-instances --instance-id "$line" --query "Reservations[].Instances[].Platform" --output text)


#If Platform WINDOWS

if echo $Platform | grep "windows" ; then


                        #Extract IDs to template assignment
                                perl /usr/lib/zabbix/externalscripts/_api/get-hostid-agent-yes-win.pl $line
                                echo "$line"

                        #Check and assign interface IP address

                                                                #Clean found switch
                                                                found=0

                                IPs=$(aws ec2 describe-instances --output=json --instance-id "$line" --query "Reservations[].Instances[].NetworkInterfaces[].PrivateIpAddresses[].PrivateIpAddress" --output text)
                                        for q in $IPs; do

                                                                                        #Check found switch
                                                                                        if [ "$found" -eq "0" ]; then

                                                if nc -z -w2 $q 10050 2>/dev/null; then
                                                address="$q"
                                                                                                found=1
                                                else
                                                address="255.255.255.255"
                                                fi

                                                echo "Address:"
                                                echo $address
                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-interface.pl "$line" "$address"
                                                                                        fi
                                        done


#If Platform LINUX

else

                        #Extract IDs to template assignment
                                perl /usr/lib/zabbix/externalscripts/_api/get-hostid-agent-yes-lin.pl $line
                                echo "$line"

                        #Check and assign interface IP address

                                                                #Clean found switch
                                                                found=0

                                IPs=$(aws ec2 describe-instances --output=json --instance-id "$line" --query "Reservations[].Instances[].NetworkInterfaces[].PrivateIpAddresses[].PrivateIpAddress" --output text)
                                        for q in $IPs; do

                                                                                        #Check found switch
                                                                                        if [ "$found" -eq "0" ]; then

                                                if nc -z -w2 $q 10050 2>/dev/null; then
                                                address="$q"
                                                                                                found=1
                                                else
                                                address="255.255.255.255"
                                                fi

                                                echo "Address:"
                                                echo $address
                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-interface.pl "$line" "$address"
                                                                                        fi
                                        done


fi


                                done

hostidswin=$(sed '1q;d' /usr/lib/zabbix/externalscripts/hosts/hostid_agent_yes_win.txt)
hostidswin=$(echo $hostidswin | sed 's/^,//g')
echo "Next:"
echo $hostidswin

hostidslin=$(sed '1q;d' /usr/lib/zabbix/externalscripts/hosts/hostid_agent_yes_lin.txt)
hostidslin=$(echo $hostidslin | sed 's/^,//g')
echo "Next:"
echo $hostidslin

#Assign template for windows instances
perl /usr/lib/zabbix/externalscripts/_api/add-template-hosts-manual.pl $hostidswin $Template_Baseline_Windows
echo "Time: $(date --iso-8601=seconds) Template assignment for Windows: $hostidswin" >> $LOG_DIR/discover-agent-yes.log

#Assign template for linux instances
perl /usr/lib/zabbix/externalscripts/_api/add-template-hosts-manual.pl $hostidslin $Template_Baseline_Linux
echo "Time: $(date --iso-8601=seconds) Template assignment for Linux: $hostidslin" >> $LOG_DIR/discover-agent-yes.log


exit 0
