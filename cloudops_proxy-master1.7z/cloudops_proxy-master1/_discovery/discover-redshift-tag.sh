#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh


IDs=$(aws redshift describe-clusters --query "Clusters[].ClusterIdentifier" --output text)
                for line in $IDs; do
                                        TAGS=$(aws redshift describe-clusters --cluster-identifier "$line" --query "Clusters[].Tags" --output text)

        #SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
#SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                        elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_REDSHIFT $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-redshift-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi


                                done


exit 0
