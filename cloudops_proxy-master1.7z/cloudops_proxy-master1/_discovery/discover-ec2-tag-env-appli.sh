#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#SSG-MONITORING Automation *****************************************************************************

IDs=$(aws ec2 describe-instances --query "Reservations[].Instances[].InstanceId" --output text)
                for line in $IDs; do

#SSG-MONITORING=OUT


                                                        if [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-MONITORING,Values=OUT" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "out $line"
#SSG-MONITORING=ENABLE
                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-MONITORING,Values=ENABLE" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "enable $line"
#SSG-MONITORING=DISABLE

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-MONITORING,Values=DISABLE" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
#SSG-ENV Automation *****************************************************************************


#SSG-ENV=DEVELOPMENT

                                                        if [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=DEVELOPMENT" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$DEVELOPMENT_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
#SSG-ENV=TEST

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=TEST" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$TEST_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "TEST $line"
#SSG-ENV=RECETTE

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=RECETTE" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$RECETTE_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "RECETTE $line"
#SSG-ENV=TRAINING

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=TRAINING" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$TRAINING_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "TRAINING $line"
#SSG-ENV=PRE-PRODUCTION

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=PRE-PRODUCTION" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$PRE_PRODUCTION_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
#SSG-ENV=PRODUCTION

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=PRODUCTION" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$PRODUCTION_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "PRODUCTION $line"
#SSG-ENV=FAILOVER

                                                        elif [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-ENV,Values=FAILOVER" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                                                                                                                                                                         GROUP2="$FAILOVER_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        else
                                                                                                                                                                                                                         GROUP2="$NOENV_NAME"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                                                                                fi

#Check group for application
APPLI=$(aws ec2 describe-instances --instance-id $line --query "Reservations[].Instances[].Tags" --output text | grep -P "^SSG-APPLI\t")
                                                                if [[ `echo $APPLI | grep "APPLI"` ]] ; then
                                                                        APPLI=$(echo $APPLI | awk '{print $2}')
                                                                fi

                                                        if [ -z "$APPLI" ]; then
                                                        APPLI="$NOAPP_NAME"
                                                        else
                                                        APPLI="$APPLI_PREFIX"$APPLI
                                                        fi

                                                   echo "Result:"
                                                                                                   echo $APPLI

GROUP3=$(echo $APPLI)

#Add discovered groups in Zabbix
perl /usr/lib/zabbix/externalscripts/_api/update-group-three-names.pl $line $EC2_NAME ${GROUP2} ${GROUP3}

              done

exit 0
