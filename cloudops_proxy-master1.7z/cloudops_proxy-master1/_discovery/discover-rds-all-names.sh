#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Clean variables
unset VALUE

IDs=$(aws rds describe-db-instances --query "DBInstances[].DBInstanceIdentifier" --output text)
                for line in $IDs; do
                                        ENDPOINT=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].Endpoint.Address" --output text)
                                        ARN=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].DBInstanceArn" --output text)

#============================ Extract Visible Name
                                                        unset DEP
                                                        DEP=$(aws rds list-tags-for-resource --resource-name ${ARN} --query "TagList[]" --output text | grep -P "^SSG-DEP\t")
                                                                if [[ `echo $DEP | grep "DEP"` ]] ; then
                                                                        DEP=$(echo $DEP | awk '{print $2}')
                                                                fi

                                                        if [ -z "$DEP" ]; then
                                                        unset DEP
                                                        else
                                                        DEP="_"$DEP
                                                        fi

                                                        CON=$ENDPOINT
                                                        if [ -z "$CON" ]; then
                                                        unset CON
                                                        else
                                                        CON="_"$CON
                                                        fi


                                                        VISIBLE=$CUSTOMER$DEP$CON
                                                        echo $VISIBLE


#Update name

                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-visible.pl $line $VISIBLE
                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-visible-name.log
                                                                                                VALUE=${VALUE}"; "$line

                done


#Send result to zabbix and print
/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.visible.check -o "${VALUE}"
echo ${VALUE}

exit 0
