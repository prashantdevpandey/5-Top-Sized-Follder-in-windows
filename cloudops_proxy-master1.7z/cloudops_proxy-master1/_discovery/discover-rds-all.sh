#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Clean variables
unset VALUE1
unset VALUE2
unset VALUE3
unset VALUE4
unset VALUE5
unset VALUE6


IDs=$(aws rds describe-db-instances --query "DBInstances[].DBInstanceIdentifier" --output text)
                for line in $IDs; do
                                        ENGINE=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].Engine" --output text)
                                                                                ENDPOINT=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].Endpoint.Address" --output text)
                                                                                ARN=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].DBInstanceArn" --output text)
																				dbname=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].DBName" --output text)

#============================ Extract Visible Name
                                                                                unset DEP
                                                        DEP=$(aws rds list-tags-for-resource --resource-name ${ARN} --query "TagList[]" --output text | grep -P "^SSG-DEP\t")
                                                                if [[ `echo $DEP | grep "DEP"` ]] ; then
                                                                        DEP=$(echo $DEP | awk '{print $2}')
                                                                fi

                                                        if [ -z "$DEP" ]; then
                                                        unset DEP
                                                        else
                                                        DEP="_"$DEP
                                                        fi

                                                                                                                CON=$ENDPOINT
                                                                                                                if [ -z "$CON" ]; then
                                                        unset CON
                                                        else
                                                        CON="_"$CON
                                                        fi


                                                        VISIBLE=$CUSTOMER$DEP$CON
                                                        echo $VISIBLE


#AWS_RDS_MySQL
                                                if [[ $ENGINE = "mysql"* ]] ; then
                                                                                                                dbtechno="MySQL"
                                                        perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_RDS_MySQL $Template_RDS $PROXY_ID $ARN $VISIBLE
                                                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API with engine $ENGINE sent for $line" >> $LOG_DIR/discover-rds.log
                                                                                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-macro.pl $line "$ENDPOINT"
                                                                                                                                                                                                                         perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-engine.pl $line "$dbtechno"
																																																						 perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-instance-name.pl $line "$dbname"
                                                        VALUE1=${VALUE1}"; "$line
#AWS_RDS_MariaDB
                                                elif [[ $ENGINE = "mariadb"* ]] ; then
                                                                                                                dbtechno="MariaDB"
                                                        perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_RDS_MariaDB $Template_RDS $PROXY_ID $ARN $VISIBLE
                                                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API with engine $ENGINE sent for $line" >> $LOG_DIR/discover-rds.log
                                                                                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-macro.pl $line "$ENDPOINT"
                                                                                                                                                                                                                         perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-engine.pl $line "$dbtechno"
																																																						 perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-instance-name.pl $line "$dbname"
                                                        VALUE2=${VALUE2}"; "$line
#AWS_RDS_Aurora
                                                elif [[ $ENGINE = "aurora"* ]] ; then
                                                                                                                dbtechno="Aurora"
                                                        perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_RDS_Aurora $Template_RDS $PROXY_ID $ARN $VISIBLE
                                                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API with engine $ENGINE sent for $line" >> $LOG_DIR/discover-rds.log
                                                                                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-macro.pl $line "$ENDPOINT"
                                                                                                                                                                                                                         perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-engine.pl $line "$dbtechno"
																																																						 perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-instance-name.pl $line "$dbname"
                                                        VALUE3=${VALUE3}"; "$line
#AWS_RDS_Oracle
                                                elif [[ $ENGINE = "oracle"* ]] ; then
                                                                                                                dbtechno="Oracle"
                                                        perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_RDS_Oracle $Template_RDS $PROXY_ID $ARN $VISIBLE
                                                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API with engine $ENGINE sent for $line" >> $LOG_DIR/discover-rds.log
                                                                                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-macro.pl $line "$ENDPOINT"
                                                                                                                                                                                                                         perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-engine.pl $line "$dbtechno"
																																																						 perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-instance-name.pl $line "$dbname"
                                                        VALUE4=${VALUE4}"; "$line
#AWS_RDS_PostgreSQL
                                                elif [[ $ENGINE = "postgres"* ]] ; then
                                                                                                                dbtechno="PostgreSQL"
                                                        perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_RDS_PostgreSQL $Template_RDS $PROXY_ID $ARN $VISIBLE
                                                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API with engine $ENGINE sent for $line" >> $LOG_DIR/discover-rds.log
                                                                                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-macro.pl $line "$ENDPOINT"
                                                                                                                                                                                                                         perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-engine.pl $line "$dbtechno"
																																																						 perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-instance-name.pl $line "$dbname"
                                                        VALUE5=${VALUE5}"; "$line
#AWS_RDS_MSSQL
                                                elif [[ $ENGINE = "sqlserver"* ]] ; then
                                                                                                                dbtechno="SQLServer"
                                                        perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_RDS_MSSQL $Template_RDS $PROXY_ID $ARN $VISIBLE
                                                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API with engine $ENGINE sent for $line" >> $LOG_DIR/discover-rds.log
                                                                                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-macro.pl $line "$ENDPOINT"
                                                                                                                                                                                                                         perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-engine.pl $line "$dbtechno"
																																																						 perl /usr/lib/zabbix/externalscripts/_api/add-host-macro-instance-name.pl $line "$dbname"
                                                        VALUE6=${VALUE6}"; "$line

                                                fi

                                done


#Send result to zabbix and print

/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.check.MySQL -o "${VALUE1}"
/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.check.MariaDB -o "${VALUE2}"
/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.check.Aurora -o "${VALUE3}"
/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.check.Oracle -o "${VALUE4}"
/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.check.PostgreSQL -o "${VALUE5}"
/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.rds.check.MSSQL -o "${VALUE6}"
echo ${VALUE1}
echo ${VALUE2}
echo ${VALUE3}
echo ${VALUE4}
echo ${VALUE5}
echo ${VALUE6}

exit 0
