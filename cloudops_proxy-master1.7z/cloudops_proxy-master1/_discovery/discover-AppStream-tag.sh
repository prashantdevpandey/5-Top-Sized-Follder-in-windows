#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh


IDs=$(aws appstream describe-fleets --output=text --query "Fleets[].Name")
                for line in $IDs; do
                                                                                ARN=$(aws appstream describe-fleets --names "$line" --query "Fleets[].Arn" --output text)
                                        TAGS=$(aws appstream list-tags-for-resource --resource "$ARN" --output json)

        #SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING\": \"OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING\": \"ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING\": \"DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
#SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV\": \"DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV\": \"TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV\": \"RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV\": \"TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV\": \"PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV\": \"PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV\": \"FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_APPSTREAM $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-AppStream-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi


                                done


exit 0
