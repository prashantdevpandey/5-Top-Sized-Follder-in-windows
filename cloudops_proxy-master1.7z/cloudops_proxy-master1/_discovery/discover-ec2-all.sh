#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Clean variables
unset VALUE

IDs=$(aws ec2 describe-instances --query "Reservations[].Instances[].InstanceId" --output text)
                for line in $IDs; do
                        dns=$(aws ec2 describe-instances --output=text --instance-id $line --query "Reservations[].Instances[].PrivateDnsName")
                                                        unset DEP
                                                        DEP=$(aws ec2 describe-instances --instance-id $line --query "Reservations[].Instances[].Tags" --output text | grep -P "^SSG-DEP\t")
                                                                if [[ `echo $DEP | grep "DEP"` ]] ; then
                                                                        DEP=$(echo $DEP | awk '{print $2}')
                                                                fi

                                                        if [ -z "$DEP" ]; then
                                                        unset DEP
                                                        else
                                                        DEP="_"$DEP
                                                        fi

                                                        ID=$line
                                                        ID="_"$ID

                                                        unset NAME
                                                        NAME=$(aws ec2 describe-instances --instance-id $line --query "Reservations[].Instances[].Tags" --output text | grep -P "^Name\t")
                                                                if [[ `echo $NAME | grep "Name"` ]] ; then
                                                                        NAME=$(echo $NAME | cut -d " " -f2- | sed -E -e 's/[[:blank:]]+/-/g')
                                                                fi

                                                        if [ -z "$NAME" ]; then
                                                        unset NAME
                                                        else
                                                        NAME="_"$NAME
                                                        fi

                                                        VISIBLE=$CUSTOMER$DEP$ID$NAME
                                                        echo $VISIBLE

                                                perl /usr/lib/zabbix/externalscripts/_api/add-host-dns-visible.pl $line $Group_EC2 $Template_EC2 $PROXY_ID $dns $VISIBLE
                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-ec2.log
                        VALUE=${VALUE}"; "$line
                done

/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.ec2.check -o "${VALUE}"
echo ${VALUE}

exit 0
