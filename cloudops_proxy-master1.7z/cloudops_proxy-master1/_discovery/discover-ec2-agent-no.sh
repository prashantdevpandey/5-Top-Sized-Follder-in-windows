#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#SSG-AGENT Interface change**************************************************************

IDs=$(aws ec2 describe-instances --query "Reservations[].Instances[].InstanceId" --output text)
                for line in $IDs; do

#SSG-AGENT=NO


                                                        if [[ `aws ec2 describe-instances --instance-id $line --filters "Name=tag:SSG-AGENT,Values=NO" --query "Reservations[].Instances[].Monitoring" --output json`  = *"State"* ]]; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-interface.pl $line "255.255.255.255"
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-agent-no.log
                                                                                                                                echo "out $line"
                                                                                                                 fi

done
exit 0
