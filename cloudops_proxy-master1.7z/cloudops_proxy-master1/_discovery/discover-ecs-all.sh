#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Clean variables
unset VALUE

IDs=$(aws ecs list-clusters --query "clusterArns[]" --output text)
                for line in $IDs; do
                        perl /usr/lib/zabbix/externalscripts/_api/add-host.pl $(echo $line | sed 's/[^=]*\///') $Group_ECS $Template_ECS $PROXY_ID
                        echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $(echo $line | sed 's/[^=]*\///')" >> $LOG_DIR/discover-ecs.log
                        VALUE=${VALUE}"; "$(echo $line | sed 's/[^=]*\///')
                done

/usr/bin/zabbix_sender -z 127.0.0.1 -s "$PROXY" -k discovery.ecs.check -o "${VALUE}"
echo ${VALUE}

exit 0
