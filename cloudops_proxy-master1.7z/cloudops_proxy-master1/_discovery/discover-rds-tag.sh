#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh


IDs=$(aws rds describe-db-instances --query "DBInstances[].DBInstanceIdentifier" --output text)
                for line in $IDs; do
                                        ENGINE=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].Engine" --output text)
                                                                                ARN=$(aws rds describe-db-instances --db-instance-identifier "$line" --query "DBInstances[].DBInstanceArn" --output text)
                                                                                TAGS=$(aws rds list-tags-for-resource --resource-name "$ARN" --query "TagList[]" --output text)

#AWS_RDS_MySQL
                                                if [[ $ENGINE = "mysql"* ]] ; then
                                                                                                GROUP=$Group_RDS_MySQL
        #SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
        #SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi



#AWS_RDS_MariaDB
                                                elif [[ $ENGINE = "mariadb"* ]] ; then
                                                                                                GROUP=$Group_RDS_MariaDB
                                                                #SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
        #SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi

#AWS_RDS_Aurora
                                                elif [[ $ENGINE = "aurora"* ]] ; then
                                                                                                GROUP=$Group_RDS_Aurora
#SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
        #SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi
#AWS_RDS_Oracle
                                                elif [[ $ENGINE = "oracle"* ]] ; then
                                                                                                GROUP=$Group_RDS_Oracle
#SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
        #SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi
#AWS_RDS_PostgreSQL
                                                elif [[ $ENGINE = "postgres"* ]] ; then
                                                                                                GROUP=$Group_RDS_PostgreSQL
#SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
        #SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi
#AWS_RDS_MSSQL
                                                elif [[ $ENGINE = "sqlserver"* ]] ; then
                                                                                                GROUP=$Group_RDS_MSSQL
#SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
        #SSG-ENV Automation *****************************************************************************


        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                                                                                elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line ${GROUP} $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-rds-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi

                                                fi

                                done


exit 0
