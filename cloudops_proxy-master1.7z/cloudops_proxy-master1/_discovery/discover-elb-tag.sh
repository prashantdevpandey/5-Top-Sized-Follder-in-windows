#!/bin/bash
#Author Blazej Michalczyk (blazej.michalczyk@soprasteria.com)

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh


IDs=$(aws elbv2 describe-load-balancers --query "LoadBalancers[].LoadBalancerName" --output text)
                for line in $IDs; do
                                        ARN=$(aws elbv2 describe-load-balancers --names "$line" --query "LoadBalancers[].LoadBalancerArn" --output text)
                                        TAGS=$(aws elbv2 describe-tags --resource-arns "$ARN" --query "TagDescriptions[].Tags[]" --output text)

        #SSG-MONITORING=OUT
                                                        if echo $TAGS | grep "SSG-MONITORING OUT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 1
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "out $line"
        #SSG-MONITORING=ENABLE
                                                        elif echo $TAGS | grep "SSG-MONITORING ENABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 0
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "enable $line"
        #SSG-MONITORING=DISABLE

                                                        elif echo $TAGS | grep "SSG-MONITORING DISABLE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-maintenance.pl $line 1
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-host-status.pl $line 0
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "disable $line"
                                                                                                                fi
#SSG-ENV Automation *****************************************************************************




        #SSG-ENV=DEVELOPMENT
                                                                                                                if echo $TAGS | grep "SSG-ENV DEVELOPMENT" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $DEVELOPMENT
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "DEVELOPMENT $line"
        #SSG-ENV=TEST

                                                        elif echo $TAGS | grep "SSG-ENV TEST" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $TEST
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "TEST $line"
        #SSG-ENV=RECETTE

                                                        elif echo $TAGS | grep "SSG-ENV RECETTE" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $RECETTE
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "RECETTE $line"
        #SSG-ENV=TRAINING

                                                        elif echo $TAGS | grep "SSG-ENV TRAINING" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $TRAINING
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "TRAINING $line"
        #SSG-ENV=PRE-PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRE-PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $PRE_PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "PRE-PRODUCTION $line"
        #SSG-ENV=PRODUCTION

                                                        elif echo $TAGS | grep "SSG-ENV PRODUCTION" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $PRODUCTION
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "PRODUCTION $line"
        #SSG-ENV=FAILOVER

                                                        elif echo $TAGS | grep "SSG-ENV FAILOVER" ; then
                                                                perl /usr/lib/zabbix/externalscripts/_api/update-group.pl $line $Group_ELBv2 $FAILOVER
                                                                                                                                echo $? "Time: $(date --iso-8601=seconds) Discovery via API sent for $line" >> $LOG_DIR/discover-elb-tag.log
                                                                                                                                echo "FAILOVER $line"
                                                        fi


                                done


exit 0
