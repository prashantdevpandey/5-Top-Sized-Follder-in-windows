#!/bin/bash
#Author: Blazej Michalczyk 2018

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Extracting parameters
while [[ $# > 1 ]]
do
        key="$1"
        case $key in
                        -h|--host)
                        INSTANCE="$2"
                        shift # past argument
                ;;
                    *)
                        # unknown option
                ;;
        esac
        shift # past argument or value
done

VALUE="aws ecs describe-clusters --clusters "${INSTANCE}" | jq '.clusters[] | {"ARN":.clusterArn, "InstancesCount": .registeredContainerInstancesCount, "PendingTasksCount": .pendingTasksCount, "RunningTasksCount": .runningTasksCount, "Status": .status, "ActiveServicesCount": .activeServicesCount}'"
OUT=`eval $VALUE`

/usr/bin/zabbix_sender -z 127.0.0.1 -s "${INSTANCE}" -k info -o "${OUT}"
echo $? "Time: $(date --iso-8601=seconds) Instance: ${INSTANCE}" >> $LOG_DIR/info-ecs.log

#temporary
echo ${OUT}

exit 0
