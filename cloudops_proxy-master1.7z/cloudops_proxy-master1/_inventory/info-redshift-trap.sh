#!/bin/bash
#Author: Blazej Michalczyk 2018

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#Extracting parameters
while [[ $# > 1 ]]
do
        key="$1"
        case $key in
                        -h|--host)
                        INSTANCE="$2"
                        shift # past argument
                ;;
                    *)
                        # unknown option
                ;;
        esac
        shift # past argument or value
done

VALUE="aws redshift describe-clusters --cluster-identifier "${INSTANCE}" | jq '.Clusters[] | {"NodeType":.NodeType, "Tags": .Tags, "ClusterNodes": .ClusterNodes, "PubliclyAccessible": .PubliclyAccessible, "ClusterStatus": .ClusterStatus, "Endpoint": .Endpoint ."Address"}'"
OUT=`eval $VALUE`

/usr/bin/zabbix_sender -z 127.0.0.1 -s "${INSTANCE}" -k info -o "${OUT}"
echo $? "Time: $(date --iso-8601=seconds) Instance: ${INSTANCE}" >> $LOG_DIR/info-redshift.log

#temporary
echo ${OUT}

exit 0
