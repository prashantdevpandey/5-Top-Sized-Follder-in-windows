#!/bin/bash
#set -x
# By Herve Wilquin 08/08/2018 Sopra Steria Group
# Some source code from F. Smith and Martha Cruz-Lesbros

ACTION=$1
RDS_INSTCE=$2
BBTMP="/tmp"
FICH=/tmp/OUTPUT.${ACTION}.$$

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

if [ "${ACTION}" == "BACKUP_AUTO_RET_PERIOD" ] ; then

#
      aws rds describe-db-instances --db-instance-identifier ${RDS_INSTCE} --output=table | sed -e 's/|/ /g'  > ${BBTMP}/${RDS_INSTCE}_describe_instance_rds.out

      VALUE=`cat ${BBTMP}/${RDS_INSTCE}_describe_instance_rds.out    | grep -w "BackupRetentionPeriod" | awk '{print $2}'`

fi

if [ "${ACTION}" == "CHECK_MULTIAZ" ] ; then
#
      MULTIAZ=$3

      aws rds describe-db-instances --db-instance-identifier ${RDS_INSTCE} --output=table | sed -e 's/|/ /g'  > ${BBTMP}/${RDS_INSTCE}_describe_instance_rds.out

      RDS_MULTIAZ=`cat ${BBTMP}/${RDS_INSTCE}_describe_instance_rds.out    | grep -w "MultiAZ" | awk '{print $2}'`

      #echo "<u>Check AWS RDS MultiAZ </u>" >> ${FICH}
      if  [ "${RDS_MULTIAZ}" != "${MULTIAZ}"  ]; then
        # echo "Check MultiAZ KO sur instance ${RDS_INSTCE} : MultiAZ=${RDS_MULTIAZ} not =  ${MULTIAZ}"
         VALUE=0
      else
        # echo "Check MultiAZ OK sur instance ${RDS_INSTCE} :   MultiAZ=${RDS_MULTIAZ} "
         VALUE=1
      fi

fi

if [ "${ACTION}" == "HISTO_CHG" ] ; then

                  aws rds describe-db-instances --db-instance-identifier ${RDS_INSTCE} --output=table | sed -e 's/|/ /g' | grep -v '+------' | grep -v 'LatestRestorableTime' > ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out

                  sdiff -s ${BBTMP}/annuaire_rds_${RDS_INSTCE}_OLD.out ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out | awk '{print $1,$2,$3,$5}' | grep -v "backing-up" | grep -v "maintenance" > ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out
                  sed -i "s/|/ to /" ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out
                  sed -i "s/^/`date '+%Y-%m-%d %H:%M:%S'` /" ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out

        #      cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out | awk '{print $1,$2,$3,$4,$5,$7}'
                  echo "Check AWS RDS Changement de Status depuis le dernier check Instance :  ${RDS_INSTCE}>" >>${FICH}
                  echo "" >>${FICH}
                  CHG=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out | grep " to "`
                  if [ "${CHG}" = "" ] ; then
                         echo "OK : Pas de Changement " >>${FICH}
                  else
                         AZCHG=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out | grep "AvailabilityZone"`
                         MODCHG=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out | grep "modifying"`

                         if [ "${AZCHG}" != "" ] ; then
                                echo "NOK : Changement de Zone de instance RDS ${RDS_INSTCE}   ==> VOIR S'IL Y A EU UN REBOOT OU UN FAILOVER...." >>${FICH}
                         else
                                   if [ "${MODCHG}" != "" ] ; then
        #                 verifier s il y a d autres lignes differentes en plus de modifying
                                          OTHERMODCHG=`grep -v "modifying"   ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out`
                                          if [ "${OTHERMODCHG}" != "" ] ; then
                                                 echo "NOK : Changement de Status de instance RDS ${RDS_INSTCE}   ==> VOIR S'IL FAUT METTRE A JOUR L'ANNUAIRE.... " >>${FICH}
                                          else
                                                 echo "ALERTE : Changement de Status de instance RDS ${RDS_INSTCE}   ==> MODIFICATION, mais n'impactant pas l'annuaire .... " >>${FICH}
                                          fi
                                   else
                                          echo "NOK : Changement de Status de instance RDS ${RDS_INSTCE}   ==> VOIR S'IL FAUT METTRE A JOUR L'ANNUAIRE.... " >>${FICH}
                                   fi
                         fi
                         cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out >>${FICH}
                  fi
                  echo "" >>${FICH}

                  echo "Historique des 30 derniers changements de l'application :  ${APPLI}" >>${FICH}
                  echo "" >>${FICH}
                  if [ -s ${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG.out ]; then
                         tail -30 ${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG.out | tac  >>${FICH}
                  else
                         echo ". Pas de Changement " >>${FICH}
                  fi
                  echo "" >>${FICH}

        # historiser et purger
                  cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}_CHG.out | grep " to " >> ${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG.out
                  tail -1000 ${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG.out >${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG_tmp.out
                  mv ${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG_tmp.out ${BBTMP}/annuaire_rds_${RDS_INSTCE}_HISTOCHG.out

        # donnees recuperees pour construction de l annuaire
                  RDS_ENGINE=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out       | grep -w "Engine" | awk '{print $2}'`
                  RDS_LICENSE=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out      | grep -w "LicenseModel" | awk '{print $2}'`
                  RDS_VERSION=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out      | grep -w "EngineVersion" | awk '{print $2}'`
                  RDS_TYPE=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out         | grep -w "DBInstanceClass" | awk '{print $2}'`
                  RDS_MULTIAZ=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out      | grep -w "MultiAZ" | awk '{print $2}'`
                  RDS_STORTYPE=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out     | grep -w "StorageType" | awk '{print $2}'`
                  RDS_IOPS=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out         | grep -w "Iops" | awk '{print $2}'`
                  if [ ${RDS_STORTYPE} == 'io1' ];then
                         RDS_TYPE_DISK='Provisioned '${RDS_IOPS}' IOPS (SSD)'
                  else
                         if [ ${RDS_STORTYPE} == 'gp2' ];then
                                RDS_TYPE_DISK='General Purpose (SSD)'
                         else
                                RDS_TYPE_DISK='Magnetic'
                         fi
                  fi
                  RDS_DISK=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out         | grep -w "AllocatedStorage" | awk '{print $2}'`
                  RDS_INSTCE=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out       | grep -w "DBInstanceIdentifier" | awk '{print $2}'`
                  RDS_CONN=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out         | grep -w "Address" | awk '{print $2}'`
                  RDS_PORT=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out         | grep -w "Port" | awk '{print $2}'`
                  RDS_ADMINUSER=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out    | grep -w "MasterUsername" | awk '{print $2}'`
                  RDS_VPC=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out          | grep -w "VpcId" | awk '{print $2}'`
                  RDS_SUBNET=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out       | grep -w "DBSubnetGroupName" | awk '{print $2}'`
                  RDS_PUBLICACCESS=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out | grep -w "PubliclyAccessible" | awk '{print $2}'`
                  RDS_AZ=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out           | grep -w "AvailabilityZone" | grep -v "SecondaryAvailabilityZone" | awk '{print $2}'`
                  RDS_SG=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out           | grep -w "VpcSecurityGroupId" | awk '{print $2}'`
                  if [ ${RDS_SG} = 'VpcSecurityGroupId' ];then
                         RDS_SG=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out        | grep -w "active" | awk '{print $2}' | sed -e '2s/sg/\,sg/' | tr  -d " \t\n\r"`
                  fi
                  RDS_PARAM=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out        | grep -w "DBParameterGroupName" | awk '{print $2}'`
                  RDS_OPTION=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out       | grep -w "OptionGroupName" | awk '{print $2}'`
                  RDS_ENCRYPT=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out      | grep -w "StorageEncrypted" | awk '{print $2}'`
                  RDS_BCKRET=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out       | grep -w "BackupRetentionPeriod" | awk '{print $2}'`
                  RDS_BCKWIND=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out      | grep -w "PreferredBackupWindow" | awk '{print $2}'`
                  RDS_MAINT=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out        | grep -w "AutoMinorVersionUpgrade" | awk '{print $2}'`
                  RDS_MAINTWIND=`cat ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out    | grep -w "PreferredMaintenanceWindow" | awk '{print $2}'`

                  echo "Annuaire Instance RDS  :  ${RDS_INSTCE} " >>${FICH}
                  echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" >>${FICH}
                  echo "RDS_INSTCE;RDS_ENGINE;RDS_LICENSE;RDS_VERSION;RDS_TYPE;RDS_MULTIAZ;RDS_TYPE_DISK;RDS_DISK Go;RDS_INSTCE;RDS_CONN:RDS_PORT;RDS_ADMINUSER;RDS_PWD;RDS_VPC;RDS_SUBNET;RDS_PUBLICACCESS;RDS_AZ;RDS_SG;RDS_PARAM;RDS_OPTION;RDS_ENCRYPT;RDS_BCKRET Days;RDS_BCKWIND (UTC);RDS_MAINT;RDS_MAINTWIND (UTC)" >> ${FICH}
                  echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" >>${FICH}

                  echo "${RDS_INSTCE};${RDS_ENGINE};${RDS_LICENSE};${RDS_VERSION};${RDS_TYPE};${RDS_MULTIAZ};${RDS_TYPE_DISK};${RDS_DISK} Go;${RDS_INSTCE};${RDS_CONN}:${RDS_PORT};${RDS_ADMINUSER};Voir Lotus;${RDS_VPC};${RDS_SUBNET};${RDS_PUBLICACCESS};${RDS_AZ};${RDS_SG};${RDS_PARAM};${RDS_OPTION};${RDS_ENCRYPT};${RDS_BCKRET} Days;${RDS_BCKWIND} (UTC);${RDS_MAINT};${RDS_MAINTWIND} (UTC)" >> ${FICH}

      mv ${BBTMP}/annuaire_rds_${RDS_INSTCE}.out ${BBTMP}/annuaire_rds_${RDS_INSTCE}_OLD.out

        # envoie vers sortie
        if [ "`cat $FICH 2>/dev/null`" = "" ] ; then
				rm -f $FICH 2>/dev/null
        else
				cat $FICH 2>/dev/null
				VALUE=`cat $FICH`
				rm -f $FICH 2>/dev/null
        fi
fi

/usr/bin/zabbix_sender -z 127.0.0.1 -s "${RDS_INSTCE}" -k ${ACTION} -o "${VALUE}"
#/usr/bin/zabbix_sender -z 127.0.0.1 -s "${RDS_INSTCE}" -k ${ACTION} -o "test"
echo $? "Time: ${end} Metric: ${ACTION}  Instance: ${RDS_INSTCE}" >> $LOG_DIR/check-rds.log
echo "${VALUE}"
exit 0
