#Configuration - replace with correct variables

#Define customer name (One word allowed, Capital letters)
CUSTOMER="SANDBOX"

#Zabbix proxy host.host name from Zabbix Web interface
PROXY="i-0b875dd83e7f65eb8"

#Zabbix proxy ID
PROXY_ID=10254

#Log directory for all scripts
LOG_DIR="/usr/lib/zabbix/externalscripts/log"

#Add http proxy for Zabbix (Leave "" if not needed)
zabbix_http_proxy=""
zabbix_https_proxy=""
zabbix_no_proxy=""

#Zabbix environment hostgroup IDs
DEVELOPMENT=87
TEST=86
RECETTE=85
TRAINING=84
PRE_PRODUCTION=81
PRODUCTION=80
FAILOVER=82

#Zabbix application hostgroup prefix (e.g. "AWS_")
APPLI_PREFIX="AWS_"

#Zabbix environment hostgroup names
DEVELOPMENT_NAME="AWS_DEVELOPMENT"
TEST_NAME="AWS_TEST"
RECETTE_NAME="AWS_RECETTE"
TRAINING_NAME="AWS_TRAINING"
PRE_PRODUCTION_NAME="AWS_PRE-PRODUCTION"
PRODUCTION_NAME="AWS_PRODUCTION"
FAILOVER_NAME="AWS_FAILOVER"
NOENV_NAME="AWS_NOENV"
NOAPP_NAME="AWS_NOAPP"
EC2_NAME="AWS_EC2"

#Zabbix AWS Service hostgroup IDs
Group_APPSTREAM=107
Group_AUTOSCALINGGROUP=93
Group_DYNAMODB=94
Group_EC2=75
Group_ECS=92
Group_ELBv2=90
Group_ELBCLASSIC=132
Group_RDS_Aurora=95
Group_RDS_MariaDB=99
Group_RDS_MSSQL=100
Group_RDS_MySQL=97
Group_RDS_Oracle=98
Group_RDS_PostgreSQL=96
Group_REDSHIFT=91

#Zabbix AWS Service hostgroup TERMINATED IDs
Group_APPSTREAM_TERMINATED=108
Group_AUTOSCALINGGROUP_TERMINATED=102
Group_DYNAMODB_TERMINATED=103
Group_EC2_TERMINATED=88
Group_ECS_TERMINATED=104
Group_ELBv2_TERMINATED=105
Group_ELBCLASSIC_TERMINATED=133
Group_RDS_TERMINATED=89
Group_REDSHIFT_TERMINATED=106


#Zabbix Templates IDs
Template_AppStream=10760
Template_AutoScalingGroup=10685
Template_DynamoDB=10688
Template_EC2=10290
Template_ECS=10683
Template_ELB=10357
Template_RDS=10703
Template_REDSHIFT=10359
Template_Baseline_Linux=10001
Template_Baseline_Windows=10081
Template_ELBCLASSIC=10999

#EOF
