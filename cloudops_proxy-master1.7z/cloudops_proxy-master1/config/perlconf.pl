#!/usr/bin/perl
#our ($url, $user, $password);

#Zabbix API configuration

        #e.g. $url = 'http://10.157.224.167/zabbix/api_jsonrpc.php';
        $url = 'http://10.157.224.167/zabbix/api_jsonrpc.php';
        
        #e.g. $user = "Admin";
        $user = "Admin";
        
        #e.g. $password = "dsfsdfsfds";
        $password = "";
        
1;
