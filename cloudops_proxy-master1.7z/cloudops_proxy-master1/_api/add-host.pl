#Loading Modules
#Author Blazej Michalczyk 2018
#Usage "add-host.pl <HOST_NAME> <GROUP_ID> <TEMPLATE_ID> <PROXY_ID>"

use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Time::Local;

#Loading Variables (perlconf.pl)
our ($url, $user, $password);
require Exporter;
require "/usr/lib/zabbix/externalscripts/config/perlconf.pl";

our $HOST_NAME = $ARGV[0];
our $GROUP_ID = $ARGV[1];
our $TEMPLATE_ID = $ARGV[2];
our $PROXY_ID = $ARGV[3];

if (not defined $HOST_NAME) {
  die "invalid argument";
}
if (not defined $GROUP_ID) {
  die "invalid argument";
}
if (not defined $TEMPLATE_ID) {
  die "invalid argument";
}
if (not defined $PROXY_ID) {
  die "invalid argument";
}

#Variables and definitions:
sub AddHostScript {
                my $client = new JSON::RPC::Client;
                my $authID;
                my $response;

#Get authentication token:
        my $json = {
                                jsonrpc => '2.0',
                method => 'user.login',
                params => {
                                user => $user,
                                password => $password
                                },
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json);
                                        die "Authentication failed\n" unless $response->content->{'result'};
                                        $authID = $response->content->{'result'};
                                        print "Authentication successful. Auth ID: " . $authID . "\n";

#Proceed to add host:

        my $json2 = {
                                "jsonrpc" => "2.0",
                                "method" => "host.create",
                                "params" => {
                                                                "host" => $HOST_NAME,
                                                                "proxy_hostid" => $PROXY_ID,
                                                                "status" => 1,
                                                                "interfaces" => [ {
                                                                                                        "type" => 1,
                                                                                                        "main" => 1,
                                                                                                        "useip" => 1,
                                                                                                        "ip" => "255.255.255.255",
                                                                                                        "dns" => "",
                                                                                                        "port" => "10050"
                                                                } ],
                                "groups" => [ {
                                                                "groupid" => "$GROUP_ID"
                                } ],
                                "templates" => [ {
                                                                "templateid" => "$TEMPLATE_ID"
                                } ],
                                "inventory_mode" => 1,
                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json2);
                                        print Dumper($response);

}


AddHostScript($HOST_NAME,$GROUP_ID,$TEMPLATE_ID,$PROXY_ID);
