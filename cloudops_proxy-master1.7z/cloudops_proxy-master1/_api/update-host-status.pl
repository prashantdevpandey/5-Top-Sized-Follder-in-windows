#Loading Modules
#Author Blazej Michalczyk 2018
#Usage "update-host-status.pl <HOST_NAME> <STATUS>"

use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Time::Local;

#Loading Variables (perlconf.pl)
our ($url, $user, $password);
require Exporter;
require "/usr/lib/zabbix/externalscripts/config/perlconf.pl";

our $HOST_NAME = $ARGV[0];
our $STATUS = $ARGV[1];

if (not defined $HOST_NAME) {
  die "invalid argument";
}
if (not defined $STATUS) {
  die "invalid argument";
}

#Variables and definitions:
sub HostStatusScript {
                my $client = new JSON::RPC::Client;
                my $authID;
                my $response;
                my $hostid;

#Get authentication token:
        my $json = {
                                jsonrpc => '2.0',
                method => 'user.login',
                params => {
                                user => $user,
                                password => $password
                                },
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json);
                                        die "Authentication failed\n" unless $response->content->{'result'};
                                        $authID = $response->content->{'result'};
                                        print "Authentication successful. Auth ID: " . $authID . "\n";

#Proceed to get HOST ID:

        my $json2 = {
                                "jsonrpc" => "2.0",
                                "method" => "host.get",
                                "params" => {
                                                                output => ['hostid'],
																"filter" => {
																			"host" => "$HOST_NAME"
																} 
								},
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json2);
										$hostid = $response->content->{result}[0]{hostid};
										#print Dumper($response);

#Proceed to change HOST Status (0=Enable 1=Disable)

		my $json3 = {
								"jsonrpc" => "2.0",
                                "method" => "host.update",
								"params" => {
											"hostid" => $hostid,
											"status"  => $STATUS
								},
								"auth"=> "$authID",
								id => 1
		};

#Handle response	
									$response = $client->call($url, $json3);
									print Dumper($response);

										
}


HostStatusScript($HOST_NAME,$STATUS);
