#Loading Modules
#Author Blazej Michalczyk & Andrzej Michalski 2018
#Usage "add-template-group.pl <HOSTGROUP> <TEMPLATE_ID>"


#Loading Modules
use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Time::Local;

#Loading Variables (perlconf.pl)
our ($url, $user, $password);
require Exporter;
require "/usr/lib/zabbix/externalscripts/config/perlconf.pl";

our $HOSTGROUP = $ARGV[0];
our $TEMPLATE = $ARGV[1];
if (not defined $HOSTGROUP) {
  die "invalid argument";
}
if (not defined $TEMPLATE) {
  die "invalid argument";
}


#API set maintenance based on zabbix hostname

sub hostaddScript {
                my $client = new JSON::RPC::Client;
                my $authID;
                my $response;
                my $hostid;

#handle start parameters
                if (defined $HOSTGROUP) {

                                my $json = {
                                                jsonrpc => '2.0',
                                                method => 'user.login',
                                                params => {
                                                                user => $user,
                                                                password => $password
                                                },
                                                id => 1
                                };

                                $response = $client->call($url, $json);
                                die "Authentication failed\n" unless $response->content->{'result'};
                                $authID = $response->content->{'result'};
                                #print "Authentication successful. Auth ID: " . $authID . "\n";
                                #Get group ID:

                                my $json2 = {
                                                                                                "jsonrpc" => "2.0",
                                                "method" => "hostgroup.get",
                                                "params" => {
                                                        output => ['groupid'],
                                                        filter => {name => $HOSTGROUP}
                                                                                        },
                                                                                                                        "auth"=> "$authID",
                                                            id => 1
                                };
                                                                $response = $client->call($url, $json2);
                                print Dumper($response);
                                                                my $groupid=$response->content->{result}[0]->{groupid};

                                                                # get host for this group
                                my $json3 = {
                                                                jsonrpc=> '2.0',
                                                                method => 'host.get',
                                                                params =>
                                                                {
                                                                        output => ['hostids'],
                                                                        groupids => [$groupid]
                                                                },
                                                                id => 1,
                                                                auth => "$authID",
                                                                };
                                                                $response = $client->call($url, $json3);
                                                                print Dumper($response);
my @hostids;
foreach  my $res (@{$response->content->{result}}) {
push @hostids, $res->{hostid};
}

#Proceed to template assignment
                my $json4 = {
                                                                "jsonrpc" => "2.0",
                                                                "method" => "template.update",
                                                                "params" => {
                                                                                        "templateid" => $TEMPLATE,                                                                                   
                                                                                        "hosts" => \@hostids

                                                                                },
                                                                "auth"=> "$authID",
                                                                id => 1
                };

#Handle response
																		$response = $client->call($url, $json4);
                                                                        print Dumper($response);


                }
                else
                {
                                print "Required parameters were not found. Please run hostaddScript(hostname)";
                }
}

hostaddScript($HOSTGROUP,$TEMPLATE);

