#Loading Modules
#Author Blazej Michalczyk 2018
#Usage "get-hostid-agent-yes-win.pl <HOST_NAME>"

use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Time::Local;

#Loading Variables (perlconf.pl)
our ($url, $user, $password);
require Exporter;
require "/usr/lib/zabbix/externalscripts/config/perlconf.pl";

our $HOST_NAME = $ARGV[0];

if (not defined $HOST_NAME) {
  die "invalid argument";
}

#Variables and definitions:
sub GroupAddScript {
                my $client = new JSON::RPC::Client;
                my $authID;
                my $response;
                my $hostid;

#Get authentication token:
        my $json = {
                                jsonrpc => '2.0',
                method => 'user.login',
                params => {
                                user => $user,
                                password => $password
                                },
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json);
                                        die "Authentication failed\n" unless $response->content->{'result'};
                                        $authID = $response->content->{'result'};
                                        print "Authentication successful. Auth ID: " . $authID . "\n";

#Proceed to get HOST ID:

        my $json2 = {
                                "jsonrpc" => "2.0",
                                "method" => "host.get",
                                "params" => {
                                                                output => ['hostid'],
                                                                                                                                "filter" => {
                                                                                                                                                        "host" => "$HOST_NAME"
                                                                                                                                }
                                                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json2);
                                                                                $hostid = $response->content->{result}[0]{hostid};
                                                                                #print Dumper($response);

#Print host id

               my $export_host="/usr/lib/zabbix/externalscripts/hosts/hostid_agent_yes_win.txt";
                                open (MYFILE, ">>", $export_host) or die "$!";                               
                                print MYFILE ",".$hostid;
                                print $hostid;
                                close MYFILE;

}


GroupAddScript($HOST_NAME);

