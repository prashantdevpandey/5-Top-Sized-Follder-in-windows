#Loading Modules
#Author Blazej Michalczyk 2018
#Usage "update-host-interface.pl <HOST_NAME> <IP>"

use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Time::Local;

#Loading Variables (perlconf.pl)
our ($url, $user, $password);
require Exporter;
require "/usr/lib/zabbix/externalscripts/config/perlconf.pl";

our $HOST_NAME = $ARGV[0];
our $IP = $ARGV[1];

if (not defined $HOST_NAME) {
  die "invalid argument";
}
if (not defined $IP) {
  die "invalid argument";
}

#Variables and definitions:
sub HostNameScript {
                my $client = new JSON::RPC::Client;
                my $authID;
                my $response;
                my $hostid;

#Get authentication token:
        my $json = {
                                jsonrpc => '2.0',
                method => 'user.login',
                params => {
                                user => $user,
                                password => $password
                                },
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json);
                                        die "Authentication failed\n" unless $response->content->{'result'};
                                        $authID = $response->content->{'result'};
                                        print "Authentication successful. Auth ID: " . $authID . "\n";

#Proceed to get HOST ID:

        my $json2 = {
                                "jsonrpc" => "2.0",
                                "method" => "host.get",
                                "params" => {
                                                                output => ['hostid'],
                                                                                                                                "filter" => {
                                                                                                                                                        "host" => "$HOST_NAME"
                                                                                                                                }
                                                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                                                                                                                                                $response = $client->call($url, $json2);
                                                                                $hostid = $response->content->{result}[0]{hostid};
                                                                                #print Dumper($response);

#Proceed to check HOST interface ID

                my $json3 = {
                                                                "jsonrpc" => "2.0",
                                                                                                                                "method" => "hostinterface.get",
                                                                "params" => {
                                                                                        "output" => "extend",
                                                                                        "hostids"  => "$hostid"
                                                                },
                                                                "auth"=> "$authID",
                                                                id => 1
                };

#Handle response
                                                                                                                                                $response = $client->call($url, $json3);
                                                                                                                                                my $interface_id = $response->content->{result}[0]{interfaceid};
                                                                        print Dumper($response);


#Proceed to change HOST interface IP

                my $json4 = {
                                                                "jsonrpc" => "2.0",
                                                                                                                                "method" => "hostinterface.update",
                                                                "params" => {
                                                                                        "interfaceid" => $interface_id,
                                                                                        "ip"  => "$IP"
                                                                },
                                                                "auth"=> "$authID",
                                                                id => 1
                };

#Handle response
                                                                                                                                                $response = $client->call($url, $json4);
                                                                        print Dumper($response);



}


HostNameScript($HOST_NAME,$IP);

