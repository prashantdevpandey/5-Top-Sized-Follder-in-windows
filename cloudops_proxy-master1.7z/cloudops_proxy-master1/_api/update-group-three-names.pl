#Loading Modules
#Author Blazej Michalczyk 2018
#Usage "update-group.pl <HOST_NAME> <GROUP1> <GROUP2>"

use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Time::Local;

#Loading Variables (perlconf.pl)
our ($url, $user, $password);
require Exporter;
require "/usr/lib/zabbix/externalscripts/config/perlconf.pl";

our $HOST_NAME = $ARGV[0];
our $GROUP1 = $ARGV[1];
our $GROUP2 = $ARGV[2];
our $GROUP3 = $ARGV[3];

if (not defined $HOST_NAME) {
  die "invalid argument";
}
if (not defined $GROUP1) {
  die "invalid argument";
}
if (not defined $GROUP2) {
  die "invalid argument";
}
if (not defined $GROUP3) {
  die "invalid argument";
}

#Variables and definitions:
sub GroupAddScript {
                my $client = new JSON::RPC::Client;
                my $authID;
                my $response;
                my $hostid;
                my $group01id;
                my $group02id;
                my $group03id;

#Get authentication token:
        my $json = {
                                jsonrpc => '2.0',
                method => 'user.login',
                params => {
                                user => $user,
                                password => $password
                                },
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json);
                                        die "Authentication failed\n" unless $response->content->{'result'};
                                        $authID = $response->content->{'result'};
                                        print "Authentication successful. Auth ID: " . $authID . "\n";

#==================================================================================================================================================================
#Proceed to get HOST ID:

        my $json2 = {
                                "jsonrpc" => "2.0",
                                "method" => "host.get",
                                "params" => {
                                                                output => ['hostid'],
                                                                                                                                "filter" => {
                                                                                                                                                        "host" => "$HOST_NAME"
                                                                                                                                }
                                                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json2);
                                                                                $hostid = $response->content->{result}[0]{hostid};
                                                                                #print Dumper($response);
#==================================================================================================================================================================
#Proceed to get GROUP1 ID:

        my $json3 = {
                                "jsonrpc" => "2.0",
                                "method" => "hostgroup.get",
                                "params" => {
                                                                output => ['groupid'],
                                                                                                                                "filter" => {
                                                                                                                                                        "name" => "$GROUP1"
                                                                                                                                }
                                                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json3);
                                                                                $group01id = $response->content->{result}[0]{groupid};
                                                                                #print Dumper($response);


#==================================================================================================================================================================
#Proceed to get GROUP2 ID:

        my $json4 = {
                                "jsonrpc" => "2.0",
                                "method" => "hostgroup.get",
                                "params" => {
                                                                output => ['groupid'],
                                                                                                                                "filter" => {
                                                                                                                                                        "name" => "$GROUP2"
                                                                                                                                }
                                                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json4);
                                                                                $group02id = $response->content->{result}[0]{groupid};
                                                                                #print Dumper($response);


#==================================================================================================================================================================
#Proceed to get GROUP3 ID:

        my $json5 = {
                                "jsonrpc" => "2.0",
                                "method" => "hostgroup.get",
                                "params" => {
                                                                output => ['groupid'],
                                                                                                                                "filter" => {
                                                                                                                                                        "name" => "$GROUP3"
                                                                                                                                }
                                                                },
                                "auth"=> "$authID",
                                id => 1
        };

#Handle response
                                        $response = $client->call($url, $json5);
                                                                                $group03id = $response->content->{result}[0]{groupid};
                                                                                #print Dumper($response);


#==================================================================================================================================================================

print Dumper($hostid);
print Dumper($group01id);
print Dumper($group02id);
print Dumper($group03id);

#==================================================================================================================================================================
#Proceed to add host to groups - always Service + ENV + application

                my $json6 = {
                                                                "jsonrpc" => "2.0",
                                                                "method" => "host.update",
                                                                "params" => {
                                                                                        "hostid" => $hostid,
                                                                                        "groups" => [ {
                                                                                                                        "groupid" => "$group01id"
                                                                                                                },
                                                                                                                                                                                                                          {
                                                                                                                        "groupid" => "$group02id"
                                                                                                                }, {
                                                                                                                        "groupid" => "$group03id"
                                                                                                                } ],
                                                                },
                                                                "auth"=> "$authID",
                                                                id => 1
                };

#Handle response
                                                                        $response = $client->call($url, $json6);
                                                                        print Dumper($response)


}


GroupAddScript($HOST_NAME,$GROUP1,$GROUP2,$GROUP3);

