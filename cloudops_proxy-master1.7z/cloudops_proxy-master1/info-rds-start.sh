#!/bin/bash

#Reading configuration data (bashconf.sh)
source /usr/lib/zabbix/externalscripts/config/bashconf.sh

#zabbix_http_proxy
if [ "$zabbix_http_proxy" = "" ]; then
echo "No http proxy"
else
export http_proxy=$zabbix_http_proxy
fi

#zabbix_https_proxy
if [ "$zabbix_https_proxy" = "" ]; then
echo "No https proxy"
else
export https_proxy=$zabbix_https_proxy
fi

#zabbix_no_proxy
if [ "$zabbix_no_proxy" = "" ]; then
echo "No proxy"
else
export no_proxy=$zabbix_no_proxy
fi



#Extracting parameters
while [[ $# > 1 ]]
do
        key="$1"
        case $key in
                        -h|--host)
                        INSTANCE="$2"
                        shift # past argument
                ;;
                    *)
                        # unknown option
                ;;
        esac
        shift # past argument or value
done

/usr/lib/zabbix/externalscripts/_inventory/info-rds-trap.sh --host ${INSTANCE} > /dev/null 2>&1 &

exit 0
